

<?php
    $ProductMRPTotal = 0;
    $ProductPriceTotal = 0;
?>

<?php $__env->startSection('title', 'My Cart'); ?>
    
<?php $__env->startSection('css-js'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="body-container" id="CartContainer">
    
    <div class="container">
    <div class="row">
    <div class="col-md-9">
    <div class="account-details-container">
    
     
        <div class="right-wishlist-container"  style="min-height: 80vh;">
    
            <div class="wishlist-basic-padding">
                <div class="account-details-title" style="padding-bottom: 0px;">
                    <span><?php if(Auth::check()): ?><?php echo e(FirstWord(Auth()->user()->name)); ?>'s <?php endif; ?> Shopping Cart (<?php echo e($cart->count()); ?> <?php if($cart->count() > 1): ?>Items <?php else: ?> Item <?php endif; ?>)</span>
                </div>
            </div>
    
            <div class="account-menu-break"></div>   
                    <?php if(!isset($cart[0])): ?>
                    <div class="wishlist-container">
                        <div class="wishlist-basic-padding">
                            <div class="w-100"  >
                                <div class="blank-wishlist-container text-center">
                                    <div class="blank-wishlist-img-container" style="margin-top: 50px;">
                                        <img class="img-nodrag" style="max-width: 35%" src="<?php echo e(asset('img/svg/blank-cart.png')); ?>">
                                    </div>
                                    <div class="blank-wishlist-txt-container text-center" style="margin-top: 30px;">
                                        <span style="font-weight: 500; font-size: 20px;">Empty Cart!</span>
                                        <br>
                                        <span>You have no items in your cart. Start adding!</span>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div> 
                    <?php else: ?>
                            
                <div class="wishlist-container">   
                    <form action="<?php echo e(route('checkout-post')); ?>" method="post" id="CartCheckOutForm"> <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $cart->Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    
                    <?php $StockCounter = 1; ?>

                            <div class="row wishlist-basic-padding" id="CartItem<?php echo e($Product->id); ?>" style="padding-bottom: 0;">
                                <div class="col-md-3">
                                    <a href="http://localhost:8000/product/<?php echo e($Product->id); ?>" target="_blank">
                                        <div class="wish-product-image-container">
                                            <img src="<?php echo e(asset('storage/images/products/'.$cart->Images->image)); ?>" alt="">
                                        </div>

                                    </a>
                                </div>
    
                                <div class="col-md-8">
                                    <a href="http://localhost:8000/product/<?php echo e($Product->id); ?>" target="_blank">
                                        <span class="wish-product-title font-weight-500 color-0066c0"><?php echo e($Product->product_name); ?></span>
                                    </a>
                                    
                                    <div class="details-price" style="margin-bottom: 0;">
                                        <span class="text-muted" style="font-size: 15px;"><font class="rupees"><s>₹</s></font><s> <?php echo e(moneyFormatIndia($Product->product_mrp * $cart->qty)); ?></s></span>
                                        <br>
                                        <span><font class="rupees" style="font-size: 18px">₹</font> <span style="font-size: 18px;"><?php echo e(moneyFormatIndia($Product->product_price * $cart->qty)); ?></span> 
                                            <b style="font-size: 15px; color: #388e3c; font-weight: 500;"> 
                                                <?php echo e(((($Product->product_mrp - $Product->product_price) / $Product->product_mrp)*100)%100); ?>% off
                                            </b>  
                                        </span>
                                        <?php
                                        if (!$Product->product_stock <= 0) {
                                            $ProductMRPTotal = $ProductMRPTotal+$Product->product_mrp * $cart->qty;
                                            $ProductPriceTotal = $ProductPriceTotal+$Product->product_price * $cart->qty;
                                            
                                        }
                                        ?>

                                        <?php if($Product->product_stock <= 0): ?>
                                            <p class="text-danger" style="font-weight: 500;"></i>Out of stock!</p>
                                        <?php else: ?>
                                        <input type="hidden" name="product_id[]" value="<?php echo e($Product->id); ?>">
                                            <div class="input-group input-group-sm" style="max-width: 160px;">
                                                <div class="input-group-prepend">
                                                <label class="input-group-text" for="product-quantity">Qty</label>
                                                </div>
                                                <select class="custom-select" id="product-quantity-<?php echo e($Product->id); ?>" name="product_qty[]" onchange="ChangeQty('<?php echo e($Product->id); ?>')">
                                                <?php while($StockCounter <= $Product->product_stock): ?>
                                                    <option <?php if($cart->qty == $StockCounter): ?> selected <?php endif; ?> value="<?php echo e($StockCounter); ?>"><?php echo e($StockCounter); ?></option>
                                                    <?php echo e($StockCounter++); ?>

                                                <?php endwhile; ?>
                                                </select>
                                            </div>
                                        <?php endif; ?>
                                        

                                    </div>
                                </div>
                                        
                                <div class="col-md-1">
                                    <div class="wishlist-remove-btn-container">
                                        <div>
                                            <a id="CartRemoveBtn" onClick="ToggleCart('<?php echo e($Product->id); ?>')" target="_blank">
                                                <span>
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                </span>
                                            </a>
                                        </div>                            
                                    </div>
                                </div>
                            </div>

                            <div class="row wishlist-basic-padding" style="padding-top: 0;"></div>

                        <div class="account-menu-break" id="CartBreak<?php echo e($Product->id); ?>"></div>      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </form>
                    </div> 
                    <?php endif; ?>

                </div>
        
            </div>
        </div>

    
            <div class="col-md-3" >
                <div class="account-details-container row" style="padding: 13px 24px;">
                    <span style="font-size: 16px; font-weight: 500;">PRICE DETAILS</span>
                </div>
                <div class="account-details-container row">
                    <div class="account-menu-items-container">
                            <span>MRP</span>
                            <span class="float-right"><strong><font class="rupees">&#8377;</font><?php echo e(moneyFormatIndia($ProductMRPTotal)); ?></strong></span>
                    </div>
                    <div class="account-menu-items-container">
                        <span>Discount</span>
                        <span class="float-right"><strong style="font-weight: 500; color: #388e3c;">- <font class="rupees">&#8377;</font><?php echo e(moneyFormatIndia($ProductMRPTotal - $ProductPriceTotal)); ?></strong></span>
                    </div>
                    <div class="account-menu-items-container">
                        <span>Delivery Charges</span>
                        <span class="float-right"><strong style="font-weight: 500; color: #388e3c;">FREE</strong></span>
                    </div>
                    <div class="account-menu-items-container"  style="font-weight: 600; color: black; font-size: 18px; border-top: 1px dashed #e0e0e0; border-bottom: 1px dashed #e0e0e0; margin-top: 18px; margin-bottom: 18px;">
                        <span>Total Amount</span>
                        <span class="float-right"><font class="rupees">&#8377;</font><?php echo e(moneyFormatIndia($ProductPriceTotal)); ?></span>
                    </div>
                        
                            <div class="w-100 cart-checkout-btn-container">
                                <button type="submit" form="CartCheckOutForm" class="">CHECKOUT &nbsp;<i class="fa fa-credit-card" aria-hidden="true"></i></button>
                            </div>
                        

                    <div class="account-menu-break"></div> 

                </div>
            </div>
      
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-js'); ?>

<script>
    function ChangeQty(product_id) {
        var cart_qty = $('#product-quantity-'+product_id).val()
        
        $('#CartItem'+product_id).fadeOut()
        $('#CartBreak'+product_id).fadeOut()

        $.ajax({
            url: "<?php echo e(route('change-qty')); ?>",
            method: 'POST',
            data: {
                'product_id'    : product_id,
                'cart_qty'      : cart_qty,
            },
            success: function (data) {

                if (data == 200) {
                    $('#CartContainer').load("<?php echo e(route('cart')); ?> #CartContainer")
                    $('#CartItem'+product_id).fadeIn()
                    $('#CartBreak'+product_id).fadeIn()

                } else {
                   console.log('Error');
                }
            }
        })
    }
</script>
    
<script>

    function ToggleCart(product_id) {

        $('#CartItem'+product_id).fadeOut()
        $('#CartBreak'+product_id).fadeOut()

        $.ajax({
            url: "<?php echo e(route('toggle-cart-btn')); ?>",
            method: 'POST',
            data: {
                'product_id' : product_id,
            },
            success: function (data) {

                if (data == 500) {
                    $('#CartContainer').load("<?php echo e(route('cart')); ?> #CartContainer")
                    $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
                } else if(data == 200) {
                    console.log('Error removing product from cart.')
                }
            }
        })

    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/cart.blade.php ENDPATH**/ ?>