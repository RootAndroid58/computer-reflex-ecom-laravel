

<?php
    $ProductMRPTotal = 0;
    $ProductPriceTotal = 0;
?>

<?php $__env->startSection('title', 'Compare'); ?>
    
<?php $__env->startSection('css-js'); ?>
    <style>
.tscroll {
  width: 100%;
  overflow-x: scroll;
  margin-bottom: 10px;
}

.tscroll table td:first-child {
    font-weight: 600;
    color: rgb(61, 61, 61);
    position: sticky;
    left: 0;
    background-color: rgb(190, 190, 190);
}

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="body-container">
    <div id="DynamicDiv">
        <div class="<?php if($compare->count() < 1): ?> container <?php else: ?> container-fluid <?php endif; ?>">
            <div class="account-details-container">
                <div class="wishlist-basic-padding" style="padding: 10px 32px;">
                    <div class="account-details-title" style="padding-bottom: 0px;">
                        <img loading=lazy src="<?php echo e(asset('/img/svg/gift-box.svg')); ?>" width="50" alt="" srcset="">
                        <span style="padding-right: 0;">Compare Products</span>
                    </div>
                </div>
                
                <div class="account-menu-break"></div>

        
            
                <?php if($compare->count() < 1): ?>
                <div class="wishlist-container">
                    <div class="wishlist-basic-padding">
                        <div class="w-100"  >
                            <div class="blank-wishlist-container text-center">
                                <div class="blank-wishlist-img-container" style="margin-top: 50px;">
                                    <img loading=lazy class="img-nodrag" style="max-width: 35%" src="<?php echo e(asset('img/svg/split_testing.svg')); ?>">
                                </div>
                                <div class="blank-wishlist-txt-container text-center" style="margin-top: 30px;">
                                    <span style="font-weight: 500; font-size: 20px;">No Products To Compare!</span>
                                    <br>
                                    <span>Please add some!</span>
                                    <div>
                                        <a href="<?php echo e(url('/')); ?>" class="btn btn-sm btn-dark mt-3 mb-3">Back To Homepage</a>
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div> 
            <?php else: ?> 
                <div class="wishlist-basic-padding" style="padding: 0px 0px;">
                    <div class="tscroll">
                        <table class="table table-striped table-bordered">
                            <tbody>
                                <tr >
                                    <td style="width: 5px;">Images</td>
                                    <?php for($i = 0; $i < $product_ids->count(); $i++): ?>
                                    <td class="item-cell-<?php echo e($compare[$i]->product->id); ?>" style="text-align: center; width: 600px !important; "> 
                                        <img loading=lazy width="150" src="<?php echo e(asset('storage/images/products/'.$compare[$i]->product->images[0]->image)); ?>" alt="">
                                    </td>
                                    <?php endfor; ?>
                                </tr>

                                <tr>
                                    <td>Name</td>
                                    <?php for($i = 0; $i < $product_ids->count(); $i++): ?>
                                    <td class="item-cell-<?php echo e($compare[$i]->product->id); ?>"><?php echo e($compare[$i]->product->product_name); ?></td>
                                    <?php endfor; ?>
                                </tr>

                                <tr>
                                    <td>Price</td>
                                    <?php for($i = 0; $i < $product_ids->count(); $i++): ?>
                                    <td class="item-cell-<?php echo e($compare[$i]->product->id); ?>"><?php echo e($compare[$i]->product->product_price); ?></td>
                                    <?php endfor; ?>
                                </tr>
                                

                                <tr>
                                    <td>Brand</td>
                                    <?php for($i = 0; $i < $product_ids->count(); $i++): ?>
                                    <td class="item-cell-<?php echo e($compare[$i]->product->id); ?>"><?php echo e($compare[$i]->product->product_brand); ?></td>
                                    <?php endfor; ?>
                                </tr>
                                
                                <?php $__currentLoopData = $specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->specification_key); ?></td>
                                    <?php for($i = 0; $i < $product_ids->count(); $i++): ?>
                                        <td class="item-cell-<?php echo e($compare[$i]->product->id); ?>">
                                            <?php $__currentLoopData = $compare[$i]->product->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                <?php if($specs->specification_key == $item->specification_key): ?>
                                                    <?php echo e($specs->specification_value); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    <?php endfor; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                                <tr>
                                    <td></td>
                                    <?php for($i = 0; $i < $product_ids->count(); $i++): ?>
                                    <td class="item-cell-<?php echo e($compare[$i]->product->id); ?>">
                                        <a href="<?php echo e(route('product-index',$compare[$i]->product->id)); ?>" class="btn btn-block btn-info">Buy Now</a>
                                        <?php
                                        if (Auth::check()) {
                                            $cart = App\Models\Cart::where('user_id', Auth()->user()->id)->where('product_id', $compare[$i]->product->id)->first();
                                        } else {
                                            $cart = App\Models\SessionCart::where('session_id', Session::getId())->where('product_id', $compare[$i]->product->id)->first();
                                        }
                                        
                                        ?>
                                        <a onclick="ToggleCart(<?php echo e($compare[$i]->product->id); ?>)" class="cursor-pointer btn btn-block <?php if(isset($cart)): ?> btn-warning <?php else: ?> btn-success <?php endif; ?> cart-btn-<?php echo e($compare[$i]->product->id); ?>"><?php if(isset($cart)): ?> Remove From Cart <?php else: ?> Add To Cart <?php endif; ?></a>
                                        
                                        <a onclick="ToggleCompare(<?php echo e($compare[$i]->product->id); ?>)" class="cursor-pointer btn btn-block btn-danger">Remove</a>
                                    </td>
                                    <?php endfor; ?>
                                </tr>

                            </tbody>
                        </table>            
                    </div>
                </div>
            <?php endif; ?>
            


          
                <div class="account-menu-break"></div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-js'); ?>


<script>
function ToggleCompare(product_id) {

    $.ajax({
        url: "<?php echo e(route('toggle-compare-btn')); ?>",
        method: 'POST',
        data: {
            'product_id' : product_id,
        },
            success: function (data) {

                if (data.compareCount < 1) {
                    $('#DynamicDiv').load("<?php echo e(route('compare')); ?> #DynamicDiv");
                }

                if (data.status == 500) {
                    $('.item-cell-'+product_id).fadeOut();
                }
                if (data.status == 500 || data.status == 200) {
                    $(".bootstrap-growl").remove();
                    $.bootstrapGrowl(data.msg, {
                        type: data.type,
                        offset: {from:"bottom", amount: 100},
                        align: 'center',
                        allow_dismis: true,
                        stack_spacing: 10,
                    })
                }
            }
    })

}


function ToggleWishlist(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-wishlist-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 500) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed from wishlist.", {
                type: "danger",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added to wishlist.", {
                type: "success",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}

function ToggleCart(product_id) {

    $.ajax({
    url: "<?php echo e(route('toggle-cart-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 200) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added To Cart.", {
                type: "success",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
            $('.cart-btn-'+product_id).removeClass('btn-success').addClass('btn-warning').html('Remove From Cart')
        } else if(data == 500) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed From Cart.", {
                type: "danger",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
            $('.cart-btn-'+product_id).removeClass('btn-warning').addClass('btn-success').html('Add To Cart')
        }
    }
})

}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/compare.blade.php ENDPATH**/ ?>