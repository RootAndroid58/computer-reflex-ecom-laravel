

<?php $__env->startSection('title', 'Support Tickets'); ?>
    

<?php $__env->startSection('nav-support-tickets', 'active'); ?>
    
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
        <!--Products Table Start-->
        <table id="AdminSupportTickets" class="table table-hover table-striped table-bordered table-fluid">
            <thead  class="bg-primary text-white">
            <tr>
                <th style="width: 15%">Ticket #</th>
                <th style="width: 10%">
                    <select name="status" id="search_status" class="form-control">
                        <option value="all" selected disabled>Status</option>
                        <option value="open">Open</option>
                        <option value="resolved">Resolved</option>
                    </select>
                </th>
                <th style="width: 30%">Subject</th>
                <th style="width: 25%">Last Replier</th>
                <th style="width: 20%">Created At</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
            <tfoot>
            <tr>
                <th>Ticket #</th>
                <th>Status</th>
                <th>Subject</th>
                <th>Last Replier</th>
                <th>Created At</th>
            </tr>
            </tfoot>
        </table>
    
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('bottom-js'); ?>
<script>

    $('document').ready(function () {
        loadDataTable()
    })

    $('#search_status').on('change', function () {
        $('#AdminSupportTickets').DataTable().destroy();
        loadDataTable()
    })

function loadDataTable() {

    var status = $('#search_status').val();

    $('#AdminSupportTickets').DataTable({
        processing: true,
        serverSide: true, 
        ajax:{
            url: "<?php echo e(route('ajax-datatable.AdminSupportTicketsTable')); ?>",
            data: { search_status:$('#search_status').val() },
        },
        columns: [
            {
                data: 'ticket_id',
                name: 'ticket_id',
            },
            {
                data        : 'status',
                name        : 'status',
                orderable   : false,
            },
            {
                data: 'subject',
                name: 'subject',
            },
            {
                data: 'last_replier',
                name: 'last_replier',
            },
            {
                data: 'created_at',
                name: 'created_at',
            },
        ]



    });
}


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/support-ticket/support-tickets.blade.php ENDPATH**/ ?>