

<?php $__env->startSection('nav-manage-ui', 'active'); ?>
<?php $__env->startSection('title','Edit Banners'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid"><div id="container">

<h3>Edit Banners</h3>

    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="container-fluid" style="padding: 24px 24px; border-bottom: 1px rgb(190, 190, 190) solid;">
                <div class="row">
                    <div class="col-3">
                        <div class="prod-back-div" style="width: 100%; height: 140px; background-image: url('<?php echo e(asset('storage/images/banner/'.$banner->banner_img)); ?>');"></div>
                    </div>
                    <div class="col-9">
                        <p>
                            <h4><?php echo e($banner->banner_name); ?></h4>
                            <span>
                                Banner Button Link: <a href="<?php echo e($banner->banner_btn_link); ?>" target="_blank"><?php echo e($banner->banner_btn_link); ?></a>
                            </span>
                            <a class="btn btn-dark float-right" href="<?php echo e(route('admin-edit-banner-page', $banner->id)); ?>">Edit</a>
                        </p>

                       
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div></div> <!--Container-Fluid End-->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/edit-banners.blade.php ENDPATH**/ ?>