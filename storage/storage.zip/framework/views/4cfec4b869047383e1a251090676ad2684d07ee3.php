
<div class="electronic-banner-area mb-5">
    <div class="row">
        <div class="col-12">
            <div class="bbb_main_container">
                <div class="bbb_viewed_title_container" >
                    <h3 class="bbb_viewed_title" style="margin-bottom: 5px;"><?php echo e($section->title); ?> 
                        <a style="font-size: 14px;" class="static-blue" target="_blank" href="<?php echo e(route('admin-edit-home-carousel-slider', $section->id)); ?>">Edit</a>
                    </h3>
                    <div class="mb-2">
                        <span ><?php echo e($section->caption); ?></span>
                    </div>
                    <div class="bbb_viewed_nav_container">
                        <div class="bbb_viewed_nav bbb_viewed_prev" onclick="PrevCarousel(<?php echo e($section->id); ?>)"><i class="fas fa-chevron-left"></i></div>
                        <div class="bbb_viewed_nav bbb_viewed_next" onclick="NextCarousel(<?php echo e($section->id); ?>)"><i class="fas fa-chevron-right"></i></div>
                    </div>
                </div>
                <div class="bbb_viewed_slider_container">
                    <div class="owl-carousel owl-carousel-<?php echo e($section->id); ?> owl-theme bbb_viewed_slider">
                        <?php $__currentLoopData = $section->SectionProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                           $product = $product->product;
                        ?>
                        <div class="owl-item">
                            <div class="product-wrapper mb-30">
                                <div class="product-img">
                                    <a href="<?php echo e(route('product-index', $product->id)); ?>" target="_blank">
                                        <div class="sm-prod-img-container" style="background-image: url('<?php echo e(asset('storage/images/products/'.$product->images[0]->image)); ?>');"></div>
                                    </a>
                                    <div class="product-action">
                                        <a class="animate-left cursor-pointer" onclick="ToggleWishlist(<?php echo e($product->id); ?>)" title="Wishlist"><i class="pe-7s-like"></i></a>
                                        <a class="animate-top cursor-pointer" onclick="ToggleCart(<?php echo e($product->id); ?>)" title="Add To Cart"><i class="pe-7s-cart"></i></a>
                                        <a class="animate-right cursor-pointer" onclick="ToggleCompare(<?php echo e($product->id); ?>)" title="Compare"><i class="pe-7s-repeat"></i></a>
                                    </div>
                                </div>
                                <div class="product-rating-4" style="text-align: center">
                                    <i class="icofont icofont-star <?php if(isset($product->stars->stars) && $product->stars->stars >= 1): ?> yellow <?php endif; ?> "></i>
                                    <i class="icofont icofont-star <?php if(isset($product->stars->stars) && $product->stars->stars >= 2): ?> yellow <?php endif; ?> "></i>
                                    <i class="icofont icofont-star <?php if(isset($product->stars->stars) && $product->stars->stars >= 3): ?> yellow <?php endif; ?> "></i>
                                    <i class="icofont icofont-star <?php if(isset($product->stars->stars) && $product->stars->stars >= 4): ?> yellow <?php endif; ?> "></i>
                                    <i class="icofont icofont-star <?php if(isset($product->stars->stars) && $product->stars->stars >= 5): ?> yellow <?php endif; ?> "></i>
                                </div>
                                <div class="product-content" style="text-align: center">
                                    <h4><a class="line-limit-2" href="<?php echo e(route('product-index', $product->id)); ?>"> <?php echo e($product->product_name); ?> </a></h4>
                                    <span><font class="rupees">₹</font> 
                                        <?php echo e(moneyFormatIndia($product->product_price)); ?>

                                        <b style="font-size: 17px; color: #388e3c; font-weight: 500;"><?php echo e(((($product->product_mrp - $product->product_price) / $product->product_mrp)*100)%100); ?>% off</b>
                                    </span>
                                    <?php if($product->product_stock <= 0): ?>
                                        <br>
                                        <span class="text-danger">Out Of Stock</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/includes/home-page-products-carousel.blade.php ENDPATH**/ ?>