

<?php $__env->startSection('nav-raise-support-ticket', 'account-menu-item-active'); ?>

<?php $__env->startSection('title', 'Raise Support Ticket'); ?>

<?php $__env->startSection('right-menu-col'); ?>
<div class="right-account-container account-details-container">
                
    <form action="<?php echo e(route('support.raise-support-ticket-submit')); ?>" method="post"> <?php echo csrf_field(); ?>

        <div class="form-group">
          <label for="help_topic">Help Topic <font style="color: red;">*</font></label>
          <select class="form-control" name="ticket_topic" id="help_topic" required>
            <option value="General Query">General Query</option>
            <option value="General Query">Account Related</option>
            <option value="Order Related">Order Related</option>
            <option value="Return/Refund">Return/Replace</option>
            <option value="Payment Related">Payment Related</option>
            <option value="Technical Problem">Technical Problem</option>
          </select>
        </div>

        <div id="subOptionDiv" class="form-group"></div>
        

        <div class="form-group">
          <label class="text-dark">Explain your issue</label>
          <textarea required name="ticket_description" id="description" class="form-control" rows="7"></textarea>
      </div>
    
        <div style="text-align: right;">
            <button type="submit" class="btn btn-success">Submit Ticket</button>
        </div>
        
    </form>


    <div class="d-none">

      <div class="form-group" id="forOrders">
        <label for="order_id_select">Order ID: <font style="color: red;">*</font></label>
        <select class="form-control" name="order_id" id="order_id_select" required>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($order->id); ?>">#<?php echo e(date_format($order->created_at,"Y-mdHis").'-'.$order->id); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-js'); ?>
    <script>
        $(document).ready(function() {
            $('#description').summernote({
              height: 250,
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.support-menu-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/support/raise-support-ticket.blade.php ENDPATH**/ ?>