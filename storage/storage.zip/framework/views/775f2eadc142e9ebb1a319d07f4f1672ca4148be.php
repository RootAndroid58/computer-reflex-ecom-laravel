

<?php $__env->startSection('content'); ?> <div class="body-container">

<?php echo $__env->yieldContent('modals'); ?>
    
<div class="container">
    <div class="row">

    <div class="col-md-3">
            <div id="ProfileDetailsDiv">
                <div class="account-details-container row" style="padding: 12px;">
                    <img class="account-dp" src="<?php echo e(asset('storage/images/dp/'.Auth()->user()->dp)); ?>">
                    <div class="account-greet">
                        <div class="account-hello">Hello,</div>
                        <div class="account-name"><?php echo e(Auth()->user()->name); ?></div>
                    </div>
                </div>
            </div>
        
                <div class="account-details-container row">
                    
                    <div class="account-menu-items-container <?php echo $__env->yieldContent('affiliate-settings-nav'); ?>">
                        <a style="width: 100%;" href="<?php echo e(route('affiliate.settings')); ?>" >
                        <div class="account-head-menu">
                            <img src="<?php echo e(asset('img/svg/settings.svg')); ?>" alt="" srcset="">
                            <span style="width: calc(100% - 26px);padding-left: 20px;font-size: 16px;font-weight: 500;margin-top: 10px;">SETTINGS</span> 
                            <img src="<?php echo e(asset('img/svg/next.svg')); ?>" alt="" class="account-menu-arrow " >
                        </div>
                    </a>
                    </div>
                
                    <div class="account-menu-break"></div> 

                    <div class="account-menu-items-container">
                        <div class="account-head-menu">
                            <img src="<?php echo e(asset('img/svg/eport.png')); ?>" alt="" srcset="">
                            <a style="cursor: default">REPORTS</a>
                        </div>
                    </div>
                        
                    
                    <div class="w-100" style="padding-bottom: 12px;">
                        <a style="width: 100%;" href="<?php echo e(route('affiliate.referred-purchases')); ?>"><div class="account-menu-item <?php echo $__env->yieldContent('referred-purchases-nav'); ?>">Referred Purchases</div></a>
                        <a style="width: 100%;" href="<?php echo e(route('affiliate.reports')); ?>"><div class="account-menu-item <?php echo $__env->yieldContent('affiliate-reports-nav'); ?>">Affiliate Reports</div></a>
                    </div>


                    <div class="account-menu-break"></div> 

                    <div class="account-menu-items-container">
                        <div class="account-head-menu">
                            <img src="<?php echo e(asset('img/svg/wallets2.svg')); ?>" alt="" srcset="">
                            <a style="cursor: default; width: 100%;">PAYMENT</a>
                        </div>
                    </div>

                    <div class="w-100" style="padding-bottom: 12px;">
                        <a href="<?php echo e(route('affiliate.wallet')); ?>"><div class="account-menu-item <?php echo $__env->yieldContent('wallet-nav'); ?>">Wallet</div></a>
                        <a href="<?php echo e(route('affiliate.payment-modes')); ?>"><div class="account-menu-item <?php echo $__env->yieldContent('payment-nav'); ?>">Payment Modes</div></a>
                        <a href="<?php echo e(route('affiliate.payout')); ?>"><div class="account-menu-item <?php echo $__env->yieldContent('payout-nav'); ?>">Payout</div></a>
                    </div>
                    
                    <div class="account-menu-break"></div> 


            </div>
    </div>


        <div class="col-md-9">

            <?php echo $__env->yieldContent('right-col-menu'); ?>


        </div>


</div>
</div>


</div> <?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/layouts/affiliate-menu-layout.blade.php ENDPATH**/ ?>