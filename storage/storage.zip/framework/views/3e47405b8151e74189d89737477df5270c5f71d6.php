<?php $__env->startSection('title', $product->product_name); ?>

<?php $__env->startSection('css-js'); ?>
    <style>
        .magnifier{
            position: fixed !important;
            margin: auto !important;
            top: 0 !important;
            bottom: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php
    $counter = 1;
    $counter2 = 1;
    
    $est_dt = new DateTime();
    $est_dt->modify( '+10 days' );
?>

<?php $__env->startSection('modals'); ?>

<div id="ReviewModalsDiv">




</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="product-details ptb-100 pb-90">
    <div class="container" >
        <div class="row">


            
            <div class="col-md-12 col-lg-7 col-12">

                <div class="product_img_slider">
                    <!-- All Images list -->
                    <div class="row">
                        <div class="col-2">
                            <ul>
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="images-menu cursor-pointer prod-back-div small_img" 
                                        style="background-image: url('<?php echo e(asset('storage/images/products/'.$image->image)); ?>');" >
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-10">
                            <div class="" style="height: 475px; text-align: center;">
                               <div style="
                                width: 100%;
                                height: 475px;
                                text-align: center;
                                line-height: 475px;
                               ">
                                   <img src="<?php echo e(asset('storage/images/products/'.$images[0]->image)); ?>" alt="" 
                                   class="big_img" id="big_img" style="vertical-align: middle;"
                                   data-image="<?php echo e(asset('storage/images/products/'.$images[0]->image)); ?>">
                               </div>
                                
                             
                            </div>
                            
                            <div class="buy-now-btn-container">
                                <?php if($product->product_stock > 0): ?> 
                                    <form action="<?php echo e(route('checkout-post')); ?>" method="post"> <?php echo csrf_field(); ?> 
                                        <input type="hidden" name="product_id[]" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="product_qty[]" value="1">
                                        <button href="#">Buy Now</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                   
                
                    <!-- Big image area/canvas -->
                    
                </div>

                

            </div> 


            
            <div class="col-md-12 col-lg-5 col-12">
                <div class="product-details-content">


                    <h3><?php echo e($product->product_name); ?></h3>
                    <div class="rating-number">
                        <div class="quick-view-rating">
                            
                            <i class="<?php if($stars >= 1): ?>fas fa-star green-star <?php else: ?> fas fa-star <?php endif; ?>" aria-hidden="true"></i>
                            <i class="<?php if($stars >= 2): ?>fas fa-star green-star <?php else: ?> fas fa-star <?php endif; ?>" aria-hidden="true"></i>
                            <i class="<?php if($stars >= 3): ?>fas fa-star green-star <?php else: ?> fas fa-star <?php endif; ?>" aria-hidden="true"></i>
                            <i class="<?php if($stars >= 4): ?>fas fa-star green-star <?php else: ?> fas fa-star <?php endif; ?>" aria-hidden="true"></i>
                            <i class="<?php if($stars >= 5): ?>fas fa-star green-star <?php else: ?> fas fa-star <?php endif; ?>" aria-hidden="true"></i>
                        </div>
                        <div class="quick-view-number">
                            <span>
                                <?php echo e($reviews->count()); ?> Rating/Review <?php if($reviews->count() > 1): ?>(S)<?php endif; ?> 
                            </span>
                        </div>
                    </div>


                    
                    <div class="details-price">
                        <span class="text-muted" style="font-size: 15px;"><font class="rupees"><s>&#8377;</font> <?php echo e(moneyFormatIndia($product->product_mrp)); ?></s></span>
                        <br>
                        <span><font class="rupees">&#8377;</font> <?php echo e(moneyFormatIndia($product->product_price)); ?> 
                            <b style="font-size: 17px; color: #388e3c; font-weight: 500;"><?php echo e($discount); ?>% off</b>
                        </span>
                        <?php if($product->product_stock <= 0): ?>
                        <br>
                        <span class="text-danger">Out Of Stock</span>
                        <?php endif; ?>
                    </div>

                    <div class="est-delivery-date">
                        <span>Est. Delivery Date: <b><?php echo e($est_dt->format( 'dS M, Y (D)' )); ?></b></span>
                    </div>
                    

                    
                    <section class="top-description">
                        <p class="top-description"><?php echo $product->product_description; ?></p>
                    </section>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Admin')): ?> 
                    <div class="row">
                        <div class="col-12 mb-1">
                            <span style="font-weight: 600; font-size: 16px;">Admin Tools</span>
                        </div>
                        <div class="col-12 mb-3">
                            <a type="button" class="btn btn-info btn-sm" data-toggle="tooltip" href="<?php echo e(route('edit-product', $product->id)); ?>"
                                title="Edit Product">
                                Edit Product
                                <i class="fa fa-cog" aria-hidden="true"></i>
                            </a>
                        </div>  
                    </div>
                    <?php endif; ?>

                    <?php if(isset($affiliateLink)): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Affiliate')): ?> 
                    <div class="row">
                        <div class="col-12 mb-1">
                            <span style="font-weight: 600; font-size: 16px;">Affiliate Tools</span>
                            <p>
                                <span>Commision: <span style="font-weight: 700;">2% (<font class="rupees">₹<font>125)</span></span>
                            </p>
                        </div>
                        <div class="col-12 mb-3">

                            <button type="button" class="btn btn-dark btn-copy js-tooltip js-copy" data-toggle="tooltip" 
                                data-placement="top" data-copy="<?php echo e(route('ShortUrlRedirect', $affiliateLink->short_url)); ?>" title="Copy to clipboard">
                                Link
                                <i class="fa fa-link" aria-hidden="true"></i>
                            </button>

                            <button type="button" class="btn btn-primary btn-copy js-tooltip js-copy" data-toggle="tooltip" 
                            data-placement="top" data-copy="<?php echo e(route('ShortUrlRedirect', $affiliateLink->short_url)); ?>" title="Copy to clipboard">
                            <i class="fab fa-facebook-square"></i>
                            </button>

                            <button type="button" class="btn btn-success btn-copy js-tooltip js-copy" data-toggle="tooltip" 
                            data-placement="top" data-copy="<?php echo e(route('ShortUrlRedirect', $affiliateLink->short_url)); ?>" title="Copy to clipboard">
                            <i class="fab fa-whatsapp-square"></i>
                            </button>

                            <button type="button" class="btn btn-primary btn-copy js-tooltip js-copy" data-toggle="tooltip" 
                            data-placement="top" data-copy="<?php echo e(route('ShortUrlRedirect', $affiliateLink->short_url)); ?>" title="Copy to clipboard">
                            <i class="fab fa-twitter-square"></i>   
                            </button>

                        </div>  
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    

                               
                    <div class="quickview-plus-minus">
                        <div class="quickview-btn-cart" style="margin-left: 0; margin-right: 5px;">
                            <a title="Cart" class="btn-hover-black" id="ToggleCartBtn" href="#"><?php if($carted == 1): ?> Remove from cart <?php else: ?> Add to cart <?php endif; ?></a>
                        </div>
                        
                        <div class="quickview-btn-wishlist">
                            <?php if(Auth::check()): ?>
                            <a title="Wishlist" id="ToggleWishlistBtn" class="btn-hover cursor-pointer <?php if($wishlisted == 1): ?> btn-wishlisted <?php else: ?> btn-not-wishlisted <?php endif; ?> ">&nbsp;<i class="fa fa-heart" aria-hidden="true"></i>&nbsp;</a>
                            <?php endif; ?>
                            <a title="Compare" style="vertical-align: unset" id="ToggleCompareBtn" class="btn cursor-pointer <?php if($compared == 1): ?> btn-danger <?php else: ?> btn-info <?php endif; ?> ">&nbsp;<i class="fas fa-repeat"></i>&nbsp;</a>
                        </div>
                    </div>

                    
                    <div class="product-details-cati-tag mt-35">
                        <ul>
                            <li class="categories-title">Category :</li>
                            <li><a href="#"><?php echo e($category->category); ?></a></li>
                        </ul>
                    </div>
                    


                </div>
            </div>   
        </div>
    </div>
</div> 










<div class="product-description-review-area pb-90">
    <div class="container-fluid" style="max-width: 1500px;">
        <div class="product-description-review text-center">

             
            <div class="description-review-title nav" role=tablist>
                <?php if($product->product_long_description != ''): ?>
                <a class="active" href="#pro-dec" data-toggle="tab" role="tab" aria-selected="true">Description</a>
                <?php endif; ?>
                <a class="<?php if(!isset($product->product_long_description)): ?> active <?php endif; ?>" href="#pro-specifications" data-toggle="tab" role="tab" aria-selected="false">Specifications</a>
            </div>


            <div class="description-review-text tab-content">
                
                <?php if(isset($product->product_long_description)): ?>
                    <div class="tab-pane active show fade" id="pro-dec" role="tabpanel">
                        <p><?php echo $product->product_long_description; ?></p>
                    </div>
                <?php endif; ?>
                
                
                <div class="tab-pane <?php if(!isset($product->product_long_description)): ?> show active <?php endif; ?> fade" id="pro-specifications" role="tabpanel">
                    
                    <div class="container">
                        <div style="text-align: center">
                            <table class="specification-table">
                                <?php $__currentLoopData = $specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width: 30%; background-color: #F3F3F3;"><?php echo e($specification->specification_key); ?></td>
                                    <td style="width: 70%;"><?php echo e($specification->specification_value); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                    

                </div>
            </div>


        </div>
    </div>
</div> 














<div class="product-description-review-area pb-90">
    <div class="container">
        <div class="product-description-review text-center">

             
            <div class="description-review-title nav" role=tablist>
                <a class="active" href="#rating_Rev" data-toggle="tab" role="tab" aria-selected="false">Ratings & Reviews
                <a href="#qna" data-toggle="tab" role="tab" aria-selected="true">Questions & Answers</a>
                </a>
            </div>


            <div class="description-review-text tab-content">

                
                
                <div class="tab-pane active show fade" id="rating_Rev" role="tabpanel">
                    <div id="RatingAreaDIV">

                    <div class="wishlist-basic-padding" style="border: 1px solid #dddddd; border-radius: 2px;"> 
                        <div class="row">
                            <div class="col-3">
                                <span style="font-size: 30px; color: rgb(27, 27, 27);">
                                    <?php echo e($stars); ?> <i class="fa fa-star" aria-hidden="true"></i>
                                </span>
                                <br>
                                <span>
                                    <?php echo e($reviews->count()); ?> Rating/Review <?php if($reviews->count() > 1): ?>(S)<?php endif; ?> 
                                </span>
                            </div>

                            <div class="col-6">
                                <div class="rating-slider-container row">
                                    <div class="col-12">

                                        <div class="row " >
                                            <div class="col-2">
                                                5 <i class="fa fa-star" aria-hidden="true"></i>
                                            </div>
        
                                            <div class="col-8">
                                                <div style="margin: auto; display: block; vertical-align: middle; padding-top: 6px;">
                                                    <div class="progress" style="height: 6px;">
                                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($ratingPerc['fivePerc']); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-2">
                                                <?php echo e(moneyFormatIndia($ratingCounts['five'])); ?>

                                            </div>
                                        </div>

                                        <div class="row " >
                                            <div class="col-2">
                                                4 <i class="fa fa-star" aria-hidden="true"></i>
                                            </div>
        
                                            <div class="col-8">
                                                <div style="margin: auto; display: block; vertical-align: middle; padding-top: 6px;">
                                                    <div class="progress" style="height: 6px;">
                                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($ratingPerc['fourPerc']); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-2">
                                                <?php echo e(moneyFormatIndia($ratingCounts['four'])); ?>

                                            </div>
                                        </div>

                                        <div class="row " >
                                            <div class="col-2">
                                                3 <i class="fa fa-star" aria-hidden="true"></i>
                                            </div>
        
                                            <div class="col-8">
                                                <div style="margin: auto; display: block; vertical-align: middle; padding-top: 6px;">
                                                    <div class="progress" style="height: 6px;">
                                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($ratingPerc['threePerc']); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-2">
                                                <?php echo e(moneyFormatIndia($ratingCounts['three'])); ?>

                                            </div>
                                        </div>

                                        <div class="row " >
                                            <div class="col-2">
                                                2 <i class="fa fa-star" aria-hidden="true"></i>
                                            </div>
        
                                            <div class="col-8">
                                                <div style="margin: auto; display: block; vertical-align: middle; padding-top: 6px;">
                                                    <div class="progress" style="height: 6px;">
                                                        <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($ratingPerc['twoPerc']); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-2">
                                                <?php echo e(moneyFormatIndia($ratingCounts['two'])); ?>

                                            </div>
                                        </div>

                                        <div class="row " >
                                            <div class="col-2">
                                                <span>
                                                    1 <i class="fa fa-star" aria-hidden="true"></i>
                                                </span>
                                                
                                            </div>
        
                                            <div class="col-8">
                                                <div style="margin: auto; display: block; vertical-align: middle; padding-top: 6px;">
                                                    <div class="progress" style="height: 6px;">
                                                        <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo e($ratingPerc['onePerc']); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-2">
                                                <?php echo e(moneyFormatIndia($ratingCounts['one'])); ?>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <?php if($ordered == 1): ?>
                            <div class="col-3">
                                <button class="btn btn-dark ReviewModalToggleBtn"><?php if($reviewed == 1): ?> Edit Review <?php else: ?> Rate Product <?php endif; ?></button>
                            </div>
                            <?php endif; ?>
                            
                        </div>

                    </div>

                    <form id="ProductReviewForm" method="POST" class="d-none"> 
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="action" value="<?php echo e(route('review-submit')); ?>">
                    <div class="modal-content ">
                        <div class="modal-body" style="display: unset;">
                
                            <div class="mb-3">
                                <span style="font-size: 18px; font-weight: 500;">Rate This Product</span>
                            </div>
                            <input type="hidden" value="<?php echo e($product->id); ?>" name="product_id">
                        
                                <div class="form-field w-100">
                                    <select id="glsr-ltr" class="star-rating" name="rating" required>
                                        <option value="" disabled selected>Select a rating</option>
                                        <option value="5" <?php if(isset($ReviewCheck->stars) && $ReviewCheck->stars == 5): ?> selected <?php endif; ?>>Fantastic</option>
                                        <option value="4" <?php if(isset($ReviewCheck->stars) && $ReviewCheck->stars == 4): ?> selected <?php endif; ?>>Great</option>
                                        <option value="3" <?php if(isset($ReviewCheck->stars) && $ReviewCheck->stars == 3): ?> selected <?php endif; ?>>Good</option>
                                        <option value="2" <?php if(isset($ReviewCheck->stars) && $ReviewCheck->stars == 2): ?> selected <?php endif; ?>>Poor</option>
                                        <option value="1" <?php if(isset($ReviewCheck->stars) && $ReviewCheck->stars == 1): ?> selected <?php endif; ?>>Terrible</option>
                                    </select>
                                </div>
                        
                            
                        </div>
                        <div style="border-top: 1px solid #dee2e6;"></div>
                        <div class="modal-body" style="display: unset;">
                            <span style="font-size: 18px; font-weight: 500;">Review This Product</span> 
                            <div class="form-group mt-3">
                            <input type="text" value="<?php echo e($ReviewCheck->title ?? ''); ?>"
                                class="form-control" maxlength="50" name="title" id="title" aria-describedby="helpId" placeholder="Title (Optional)">
                            </div>
                
                            <div class="form-group">
                            <textarea maxlength="300" class="form-control" name="message" id="" rows="4" placeholder="Detailed Review..."><?php echo e($ReviewCheck->message ?? ''); ?></textarea>
                            </div>
                
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary ReviewModalToggleBtn" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                    </form>

                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php if($review->message != '' || $review->title != ''): ?>
                        <div class="wishlist-basic-padding" style="border: 1px solid #dddddd; border-radius: 2px; border-top: 0;">
                            <div class="row">
                                <button type="button" class="btn btn-dark btn-sm">
                                    
                                    <?php echo e($review->stars); ?> <span><i class="fa fa-star" aria-hidden="true"></i></span>
                                </button>
                                <span style="padding-left: 12px; padding-top: 3px; font-size: 14px; color: #212121; font-weight: 500;"><?php echo e($review->title ?? ''); ?></span>
                            </div>
                            <div class="row">
                                <span style="margin: 12px 0;">
                                    <?php echo e($review->message); ?>

                                </span>
                            </div>

                            <div class="row">
                                <span style="margin: 12px 0;">
                                    <?php echo e($review->user->name); ?> <img width="14" src="<?php echo e(asset('img/svg/verified-tick.svg')); ?>" alt=""> (Buyer), <?php echo e(HowMuchOldDate($review->created_at, 'days')); ?> ago
                                </span>
                            </div>
                        </div>        
                           
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($reviews->count() >= 1): ?>
                        <div class="view-more-continer mt-3" >
                            <a href="<?php echo e(route('all-product-reviews', $product->id)); ?>">
                                <span style="color: #0066c0;" class="hover-blue"> All <?php echo e(App\Models\ProductReview::where('product_id', $product->id)->count()); ?> Reviews <i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </a>
                        </div>
                    <?php endif; ?>
                    

                </div>
            </div>



                
                <div class="tab-pane fade" id="qna" role="tabpanel">
                    
                    QnA Section

                </div>

            </div>


        </div>
    </div>
</div> 











<!-- Related products area start -->
<div class="product-area pb-95">
    <div class="container">
        <div class="section-title-3 text-center mb-50">
            <h2>Related products</h2>
        </div>
        <div class="product-style">
            <div class="related-product-active owl-carousel">

                <?php if(isset($RelatedProducts)): ?>
                <?php $__currentLoopData = $RelatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RelatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($RelatedProduct->id != $product->id): ?>
                <div class="product-wrapper">
                    <div class="product-img">
                        <a href="<?php echo e(route('product-index', $RelatedProduct->id)); ?>">
                            <div class="sm-prod-img-container" style="background-image: url('<?php echo e(asset('storage/images/products/'.$RelatedProduct->images[0]->image)); ?>');"></div>
                        </a>
                        <div class="product-action">
                            <a class="animate-left" title="Wishlist" onclick="ToggleWishlist(<?php echo e($RelatedProduct->id); ?>)" style="cursor: pointer;">
                                <i class="pe-7s-like"></i>
                            </a>
                            <a class="animate-right" title="Add To Cart" onclick="ToggleCart(<?php echo e($RelatedProduct->id); ?>)" style="cursor: pointer;">
                                <i class="pe-7s-cart"></i>
                            </a>
                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="<?php echo e(route('product-index', $RelatedProduct->id)); ?>" target="_blank" class="line-limit-2" title="<?php echo e($RelatedProduct->product_name); ?>"> <?php echo e($RelatedProduct->product_name); ?> </a></h4>
                        <span><font class="rupees">₹</font> 
                            <?php echo e(moneyFormatIndia($RelatedProduct->product_price)); ?>

                            <b style="font-size: 17px; color: #388e3c; font-weight: 500;"><?php echo e(((($RelatedProduct->product_mrp - $RelatedProduct->product_price) / $RelatedProduct->product_mrp)*100)%100); ?>% off</b>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<!-- Related products area end -->




<div class="d-none">
    <form>
        <input name="product_id" value="<?php echo e($product->id); ?>">
    </form> 
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>





<script>

// COPY TO CLIPBOARD
// Attempts to use .execCommand('copy') on a created text field
// Falls back to a selectable alert if not supported
// Attempts to display status in Bootstrap tooltip
// ------------------------------------------------------------------------------

function copyToClipboard(text, el) {
  var copyTest = document.queryCommandSupported('copy');
  var elOriginalText = el.attr('data-original-title');

  if (copyTest === true) {
    var copyTextArea = document.createElement("textarea");
    copyTextArea.value = text;
    document.body.appendChild(copyTextArea);
    copyTextArea.select();
    try {
      var successful = document.execCommand('copy');
      var msg = successful ? 'Copied!' : 'Whoops, not copied!';
      el.attr('data-original-title', msg).tooltip('show');
    } catch (err) {
      console.log('Oops, unable to copy');
    }
    document.body.removeChild(copyTextArea);
    el.attr('data-original-title', elOriginalText);
  } else {
    // Fallback if browser doesn't support .execCommand('copy')
    window.prompt("Copy to clipboard: Ctrl+C or Command+C, Enter", text);
  }
}

$(document).ready(function() {
  // Initialize
  // ---------------------------------------------------------------------

  // Tooltips
  // Requires Bootstrap 3 for functionality
  $('.js-tooltip').tooltip();

  // Copy to clipboard
  // Grab any text in the attribute 'data-copy' and pass it to the 
  // copy function
  $('.js-copy').click(function() {
    var text = $(this).attr('data-copy');
    var el = $(this);
    copyToClipboard(text, el);
  });
});
</script>




<script>


function ToggleCompare(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-compare-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {
        if (data.status == 500 || data.status == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl(data.msg, {
                type: data.type,
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}



    function ToggleWishlist(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-wishlist-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 500) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed from wishlist.", {
                type: "danger",
                offset: {from:"bottom", amount: 50},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added to wishlist.", {
                type: "success",
                offset: {from:"bottom", amount: 50},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}

function ToggleCart(product_id) {

    $.ajax({
    url: "<?php echo e(route('toggle-cart-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 200) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added To Cart.", {
                type: "success",
                offset: {from:"top", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 500) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed From Cart.", {
                type: "danger",
                offset: {from:"top", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}
</script>















    
    <script>
        $(document).ready(function() {

            $('#ToggleCartBtn').click(function (e) {

                e.preventDefault()

                var product_id  = $('input[name="product_id"]').val()

                console.log(product_id)

                $.ajax({
                    url: "<?php echo e(route('toggle-cart-btn')); ?>",
                    method: 'POST',
                    data: {
                        'product_id' : product_id,
                    },
                    success: function (data) {

                        if (data == 200) {
                            console.log('Added to cart')
                            $('#ToggleCartBtn').html('remove from cart')
                            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
                        } else if(data == 500) {
                            $('#ToggleCartBtn').html('add to cart')
                            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
                        }
                    }
                })
            })



            $('#ToggleCompareBtn').click(function (e) {

                e.preventDefault()

                var product_id  = $('input[name="product_id"]').val()

                console.log(product_id)

                $.ajax({
                    url: "<?php echo e(route('toggle-compare-btn')); ?>",
                    method: 'POST',
                    data: {
                        'product_id' : product_id,
                    },
                    success: function (data) {
                        if (data.status == 500 || data.status == 200) {
                            $(".bootstrap-growl").remove();
                            $.bootstrapGrowl(data.msg, {
                                type: data.type,
                                offset: {from:"bottom", amount: 100},
                                align: 'center',
                                allow_dismis: true,
                                stack_spacing: 10,
                            })
                        }

                        if (data.status == 200) {
                            console.log(200);
                            $('#ToggleCompareBtn').addClass('btn-danger').removeClass('btn-info')
                            // $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
                        } else if(data.status == 500) {
                            console.log(500);
                            $('#ToggleCompareBtn').addClass('btn-info').removeClass('btn-danger')
                            // $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
                        }
                    }
                })
            })
        })
    </script>


    
    <script>
        $(document).ready(function() {

            $('#ToggleWishlistBtn').click(function (e) {

                e.preventDefault()

                var product_id  = $('input[name="product_id"]').val()

                console.log(product_id)

                $.ajax({
                    url: "<?php echo e(route('toggle-wishlist-btn')); ?>",
                    method: 'POST',
                    data: {
                        'product_id' : product_id,
                    },
                    success: function (data) {

                        if (data == 200) {
                            $('#ToggleWishlistBtn').addClass('btn-wishlisted').removeClass('btn-not-wishlisted')
                        } else if(data == 500) {
                            $('#ToggleWishlistBtn').addClass('btn-not-wishlisted').removeClass('btn-wishlisted')
                        }
                    }
                })
            })
        })
    </script>
    
	<script>
		$(document).ready(function(){
			$('#big_img').imagezoomsl({
                cursorshade:true,
                magnifycursor:'zoom-in',
				zoomrange: [2, 10],
                scrollspeedanimate: 5,
                zoomspeedanimate: 1,
                loopspeedanimate: 1,  
                magnifierspeedanimate: 350,
                magnifiersize: ['43%', '75vh'],
                leftoffset:  15, 						// îòñòóï ñëåâà îò tmb êàðòèíêè
				rightoffset: 15, 	    
			})
		})
	</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/product-details.blade.php ENDPATH**/ ?>