

<?php $__env->startSection('nav-admin-user-management', 'active'); ?>
<?php $__env->startSection('title','Edit Admin User'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">


    <div class="modal fade" id="UserDeleteConfirmationModal-<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title"><strong>Admin Remove Confirmation</strong> </h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              Are you sure removing this user from Admin access?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a type="button" class="btn btn-danger" href="<?php echo e(url('/admin/user-management/id/'.$user->id.'/delete')); ?>">Remove</a>
            </div>
          </div>
        </div>
      </div>









<h3 class="text-dark">Edit User</h3>
<h5 class="text-dark text-center"><i style="color: rgb(255, 196, 0)" class="fa fa-circle"></i> You're currently editing <img width="40px" height="40px" style="border-radius: 50%;" src="<?php echo e(asset("storage/images/dp/$user->dp")); ?>"> <strong><?php echo e($user->name); ?></strong></h5>

<div class="container form-container p-5" style="background-color: rgb(225, 227, 240); box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
<div class="row mt-3 mb-3">
    <div class="col-6 text-center">
        Date Created <strong><?php echo e($user->created_at ?? '--'); ?></strong>
    </div>

    <div class="col-6 text-center">
        Last Updated <strong><?php echo e($user->updated_at); ?></strong>
    </div>
</div>

<form method="POST" action="<?php echo e(route('admin-user-edit-submit')); ?>">
<?php echo csrf_field(); ?>
<input type="hidden" name="user_id" id="id" value="<?php echo e($user->id); ?>">
<div class="form-row">
    <div class="form-group col-md-12">
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">Full Name</div>
            </div>
            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name') ?? $user->name); ?>" placeholder="Full Name">
        </div>    
    </div>    
</div>


<div class="form-row">
    <div class="form-group col-md-6">
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">Email ID</div>
            </div>
            <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email') ?? $user->email); ?>" placeholder="Email ID">
        </div>    
    </div>    

    <div class="form-group col-md-6">
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">Mobile Number</div>
            </div>
            <input type="text" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile" value="<?php echo e(old('mobile') ?? $user->mobile); ?>" placeholder="Mobile Number">
        </div>   
    </div>
</div>

<h5>Permissions</h5>

<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="form-check">
    <input class="form-check-input" style="cursor: pointer;" type="checkbox" id="<?php echo e($permission->name); ?>" name="NewPermissions[]" value="<?php echo e($permission->name); ?>"   
    <?php $__currentLoopData = $userPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userPermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($userPermission->name == $permission->name): ?>
        checked
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
    <label class="form-check-label" style="cursor: pointer;" for="<?php echo e($permission->name); ?>">
        <?php echo e($permission->name); ?>

    </label>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<div class="container-fluid text-right">
    <a data-toggle="modal" data-target="#UserDeleteConfirmationModal-<?php echo e($user->id); ?>" class="btn btn-danger">Delete User</a>
    <button type="submit" class="btn btn-success">Save Changes</button>
</div>

</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/admin-user-edit.blade.php ENDPATH**/ ?>