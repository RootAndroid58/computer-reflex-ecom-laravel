

<?php $__env->startSection('title', 'Affiliate Reports'); ?>

<?php $__env->startSection('affiliate-reports-nav', 'account-menu-item-active'); ?>

<?php $__env->startSection('right-col-menu'); ?>
    
     
<div class="right-account-container account-details-container"style="padding: 24px 24px;">
     
  <div class="container-fluid">
      <h5 class="mb-3" style="font-weight: 600;">Affiliate Reports</h5>
  </div>
  
<div class="container-fluid">


  
</div>

</div>


<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.affiliate-menu-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/affiliate/reports.blade.php ENDPATH**/ ?>