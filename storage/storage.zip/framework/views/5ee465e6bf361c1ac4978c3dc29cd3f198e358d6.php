

<?php $__env->startSection('nav-manage-ui', 'active'); ?>
<?php $__env->startSection('title','Manage Banners'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid"><div id="container">


    <h3>Banners Management</h3>


<div class="row">

    <div class="col-md-4">
        <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('admin-new-banner')); ?>">New Banner</a>
    </div>

    <div class="col-md-4">
        <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('admin-edit-banners')); ?>">Show / Edit Banners</a>
    </div>

    <div class="col-md-4">
        <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('admin-publish-banners')); ?>">Publish Banners</a>
    </div>

</div>






</div></div> <!--Container-Fluid End-->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/manage-banners.blade.php ENDPATH**/ ?>