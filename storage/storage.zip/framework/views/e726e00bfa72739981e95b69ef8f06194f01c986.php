

<?php $__env->startSection('title', 'Search: '.Request()->search); ?>
    


<?php $__env->startSection('content'); ?>


<div class="shop-page-wrapper shop-page-padding ptb-50">
    <div class="container-fluid">
        <div>
        <div class="row">
            
            <div class="col-lg-2">
                <div id="SideBar">
                    <div class="shop-sidebar mr-50">
                    <form method="GET" action="<?php if(isset($slug)): ?><?php echo e(route('show-catalog', $slug)); ?><?php else: ?><?php echo e(route('search')); ?><?php endif; ?>" id="filter_form">
                        <input type="hidden" name="sort_by" value="">
                        <input type="hidden" name="search" value="<?php echo e(request()->search); ?>">
                        <div class="sidebar-widget mb-45">
                            <h3 class="sidebar-title">Filter By Category</h3>
                            <div class="sidebar-categories">
                            <div class="form-group">
                                <select onchange="submitFilterForm()" class="" name="category" id="" style="height: 30px; cursor: pointer;" >
                                <option value="all">All</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category); ?>" <?php if($category->category == request()->category): ?> selected <?php endif; ?>><?php echo e($category->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            </div>
                        </div>
                
                        <div class="sidebar-widget mb-40">
                            <h3 class="sidebar-title">Filter by Price</h3>
                            <div class="price_filter">
                                <div class="price_slider_amount">
                                    <div class="_2b0bUo">
                                        <div class="_1YAKP4">
                                            <input  onkeyup="submitFilterForm()" type="number" name="min_price" class="_2YxCDZ" value="<?php echo e(request()->min_price ?? ''); ?>">
                                            <small id="helpId" class="form-text text-muted">Min Price</small>
                                        </div>

                                            <div class="_3zohzR">To</div>
                                        
                                            <div class="_3uDYxP">
                                                <input onkeyup="submitFilterForm()" type="number" name="max_price" class="_2YxCDZ" value="<?php echo e(request()->max_price ?? ''); ?>">
                                                <small id="helpId" class="form-text text-muted">Max Price</small>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-widget mb-40">
                            <h3 class="sidebar-title">Availability</h3>
                                <div class="form-check">
                                    <input onchange="submitFilterForm()" class="form-check-input" type="checkbox" name="stock" value="checked" id="flexCheckDefault" <?php if(request()->stock == 'checked'): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="flexCheckDefault">
                                        Show Out Of Stock Items
                                    </label>
                                </div>
                        </div>

                    
                        <div class="sidebar-widget mb-40">
                            <h3 class="sidebar-title">Specifications</h3>
                                
                                <?php $__currentLoopData = $SpecsFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Group => $SpecsGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="collapse-item">
                                    <?php
                                    if (isset(Request()->specs[$Group])) {
                                        $checked = Request()->specs[$Group];
                                    } else {
                                        $checked = null;
                                    }
                                    ?>
                                    <div class="collapse-btn <?php if($checked != null): ?> on <?php endif; ?>" style="padding: 7px 10px; transition: all 200ms; background-color: rgba(212, 212, 212, 0.781);">
                                        <span style="font-weight: 600"><?php echo e($Group); ?></span>
                                    </div>
                                    <div class="collapse-content" style="<?php if($checked != null): ?> max-height: fit-content; transition: all 200ms; <?php endif; ?> ">
                                       
                                        <?php $__currentLoopData = $SpecsGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Specs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="padding-top: 6px; padding-bottom: 6px;">
                                                <div class="form-check">
                                                    <input onchange="submitFilterForm()" class="form-check-input cursor-pointer" name="specs[<?php echo e($Group); ?>]" value="<?php echo e($Specs->specification_value); ?>" type="checkbox" id="<?php echo e($Specs->specification_value.$Specs->id); ?>" <?php if($checked == $Specs->specification_value): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label cursor-pointer line-limit-2" for="<?php echo e($Specs->specification_value.$Specs->id); ?>"><?php echo e($Specs->specification_value); ?></label>
                                                </div>
                                            </div>
                                            <div class="account-menu-break"></div>  
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            




            <div class="col-lg-10">
                <div id="RowDiv" class="w-100">
                    <div class="shop-product-wrapper res-xl">
                        <div class="shop-bar-area">



                            <div class="shop-bar pb-60">
                                <div class="shop-found-selector">
                                    <div class="shop-found">
                                        <p><span><?php echo e($ProductsCount); ?></span> Products Found</p>
                                    </div>
                                    <div class="shop-selector">
                                        <label>Sort By : </label>
                                        <select id="sort_by_select">
                                            <option value="Default">Default</option>
                                            <option <?php if(Request()->sort_by == 'A to Z'): ?> selected <?php endif; ?> value="A to Z">A to Z</option>
                                            <option <?php if(Request()->sort_by == 'Z to A'): ?> selected <?php endif; ?> value="Z to A">Z to A</option>
                                            <option <?php if(Request()->sort_by == 'Price Low to High'): ?> selected <?php endif; ?> value="Price Low to High">Price Low to High</option>
                                            <option <?php if(Request()->sort_by == 'Price High to Low'): ?> selected <?php endif; ?> value="Price High to Low">Price High to Low</option>
                                            
                                        </select>
                                    </div>
                                </div>
                                <div class="shop-filter-tab">
                                    <div class="shop-tab nav" role=tablist>
                                        <a class="active" href="#grid-sidebar3" data-toggle="tab" role="tab" aria-selected="false">
                                            <i class="ti-layout-grid4-alt"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>



                            <div class="shop-product-content tab-content">
                                <div id="grid-sidebar3" class="tab-pane fade active show">
                                    <div class="row">

                                        
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 col-xl-3">             
                                            <div class="product-wrapper mb-30">
                                                <div class="product-img">
                                                    <a href="<?php echo e(route('product-index', $product->id)); ?>" target="_blank">
                                                        <div class="sm-prod-img-container prod-back-div" style="background-image: url('<?php echo e(asset('storage/images/products/'.$product->images[0]->image)); ?>');"></div>
                                                    </a>
                                                    <div class="product-action">
                                                        <a class="animate-left cursor-pointer" onclick="ToggleWishlist(<?php echo e($product->id); ?>)" title="Wishlist"><i class="pe-7s-like"></i></a>
                                                        <a class="animate-top cursor-pointer" onclick="ToogleCart(<?php echo e($product->id); ?>)" title="Add To Cart"><i class="pe-7s-cart"></i></a>
                                                        <a class="animate-right cursor-pointer" onclick="ToggleCompare(<?php echo e($product->id); ?>)" title="Compare"><i class="pe-7s-repeat"></i></a>
                                                    </div>
                                                </div>
                                                <div class="product-content">
                                                    <h4><a class="line-limit-3" href="<?php echo e(route('product-index', $product->id)); ?>"> <?php echo e($product->product_name); ?> </a></h4>
                                                    <span><font class="rupees">₹</font> 
                                                        <?php echo e(moneyFormatIndia($product->product_price)); ?>

                                                        <b style="font-size: 17px; color: #388e3c; font-weight: 500;"><?php echo e(((($product->product_mrp - $product->product_price) / $product->product_mrp)*100)%100); ?>% off</b>
                                                    </span>
                                                    <?php if($product->product_stock <= 0): ?>
                                                        <br>
                                                        <span class="text-danger">Out Of Stock</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
            
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                
                    <div>
                        <?php echo e($products->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>



        </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('bottom-js'); ?>
<script>
function ToggleCompare(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-compare-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {
        if (data.status == 500 || data.status == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl(data.msg, {
                type: data.type,
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}



function ToggleWishlist(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-wishlist-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 500) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed from wishlist.", {
                type: "danger",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added to wishlist.", {
                type: "success",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}

function ToogleCart(product_id) {

    $.ajax({
    url: "<?php echo e(route('toggle-cart-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 200) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added To Cart.", {
                type: "success",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 500) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed From Cart.", {
                type: "danger",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}


$('#ToggleCartBtn').click(function (e) {

e.preventDefault()

var product_id  = $('input[name="product_id"]').val()

console.log(product_id)

$.ajax({
    url: "<?php echo e(route('toggle-cart-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 200) {
            console.log('Added to cart')
            $('#ToggleCartBtn').html('remove from cart')
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
        } else if(data == 500) {
            $('#ToggleCartBtn').html('add to cart')
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
        }
    }
})
})
</script>


<script>
    
  var acc = document.getElementsByClassName("collapse-btn");
  for (let i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
      this.classList.toggle("on");
      var panel = this.nextElementSibling;
      if (panel.style.maxHeight){
        panel.style.maxHeight = null;
      } else {
        panel.style.maxHeight = panel.scrollHeight + "px";
      }
    });
  }

</script>

<script>
    function submitFilterForm() {
        $('#filter_form').submit();
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/searched-products.blade.php ENDPATH**/ ?>