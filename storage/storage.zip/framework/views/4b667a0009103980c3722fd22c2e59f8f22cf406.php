


<?php $__env->startSection('title', 'Order Placed'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="body-container" id="CartContainer">

    
    
    <div class="container">
        <div class="row">
        <div class="col-md-12">
        <div class="account-details-container">
            <div class="right-wishlist-container" style="min-height: 0;">
        
                <div class="wishlist-basic-padding" style="padding: 10px 32px;">
                    <div class="account-details-title" style="padding-bottom: 0px;">
                        <img src="<?php echo e(asset('/img/svg/happy-birth-day.svg')); ?>" width="50" alt="" srcset="">
                        <span style="padding-right: 0;">Order Placed</span> #<?php echo e(date_format($data['order']->created_at,"Y-mdHis").'-'.$data['order']->id); ?>

                    </div>
                </div>
        
                <div class="account-menu-break"></div>   
                                                    
                    <div class="wishlist-container">   
                                                                 
                            <div class="account-menu-break"></div>     
                                <div class="wishlist-basic-padding" id="CartItem2" style="padding-bottom: 0;">
                                    <div class="order-confirmation-notes">
                                        <span>Order will get delivered by <span style="font-weight: 500;"><?php echo e(date_format(new DateTime($data['order']->delivery_date), "dS M, Y (D)")); ?></span></span><br>
                                        <span>You'll receive email once your order gets shipped.</span><br>
                                        <span>If you need any help, feel free to <a href="#">Contact us</a>.</span>
                                    </div>
                                </div>
                                
                                <div class="row wishlist-basic-padding" style="padding-top: 0;"></div>
                            <div class="account-menu-break" id="CartBreak2"></div>      
                             
                        </div> 
                        
                    </div>
            
                </div>
            </div>
          
            </div>
        </div>
    
    
    





    
    <div class="container">
    <div class="row">
    <div class="col-md-12">
    <div class="account-details-container">
        <div class="right-wishlist-container" style="min-height: 0;">
    
            <div class="wishlist-basic-padding">
                <div class="account-details-title" style="padding-bottom: 0px;">
                    <div class="row">
                        <div class="col-6">
                            <span>Delivery Address</span>
                        </div>
                        <div class="col-6">
                            <span>Order Summary</span>
                        </div>
                    </div>
                </div>
            </div>
    
            <div class="account-menu-break"></div>   
                                                
                <div class="wishlist-container">   
                    <form action="http://localhost:8000/checkout" method="post" id="CartCheckOutForm"> <input type="hidden" name="_token" value="WwI9Iew3SQzo763ogSnhQVllI4PQx3i4qUOQURAF">                                         

                        <div class="account-menu-break"></div>     
                         
                            <div class="row wishlist-basic-padding" id="CartItem2" style="padding-bottom: 0;">

    
                                <div class="col-6">
                                    <p>
                                        <span style="font-weight: 500;"><?php echo e($data['address']->name); ?></span> <br>
                                        <?php echo e($data['address']->house_no); ?>, <br>
                                        <?php echo e($data['address']->locality); ?>, <br>
                                        <?php echo e($data['address']->city); ?>, <br>
                                        <?php echo e($data['address']->district); ?>, <br>
                                        <?php echo e($data['address']->state); ?>, <?php echo e($data['address']->pin_code); ?> <br>
                                    </p>
                                    <p>
                                        <span style="font-weight: 500;">Contact information</span><br>
                                        <?php echo e($data['address']->mobile); ?><?php if(isset($data['address']->alt_mobile)): ?>, <?php echo e($data['address']->alt_mobile); ?><?php endif; ?>
                                        
                                    </p>
                                </div>

                                <div class="col-6">
                                    <table style="width: 100%;">
                                        <tr style="width: 100%">
                                            <td style="width: 50%; font-weight: 500;">Payment Method:</td>    
                                            <td style="width: 50%; text-align: right;"><?php if($data['order']->payment_method == 'cod'): ?> Cash On Delivery <?php elseif($data['order']->payment_method == 'paytm'): ?> PayTM <?php elseif($data['order']->payment_method == 'payu'): ?> PayU <?php endif; ?></td>    
                                        </tr>    
                                        <tr style="width: 100%">
                                            <td style="width: 50%; font-weight: 500;">Items Ordered:</td>    
                                            <td style="width: 50%; text-align: right;"><?php echo e($data['items']->count()); ?></td>    
                                        </tr>    
                                        <tr style="width: 100%">
                                            <td style="width: 50%; font-weight: 500;">Order MRP:</td>    
                                            <td style="width: 50%; text-align: right;"><font class="rupees">₹</font><?php echo e(moneyFormatIndia($data['order']->mrp)); ?></td>    
                                        </tr>    
                                        <tr style="width: 100%">
                                            <td style="width: 50%; font-weight: 500;">Discount:</td>    
                                            <td style="width: 50%; text-align: right; color: #388e3c;">-<font class="rupees">₹</font><?php echo e(moneyFormatIndia($data['order']->mrp - $data['order']->price)); ?></td>    
                                        </tr>    
                                        <tr style="width: 100%; font-size: 16px; ">
                                            <td style="width: 50%; font-weight: 500; padding-top: 10px;">Grand Total:</td>    
                                            <td style="width: 50%; font-weight: 500; color: black; text-align: right; padding-top: 10px;"><font class="rupees">₹</font><?php echo e(moneyFormatIndia($data['order']->price)); ?></td>    
                                        </tr>   
                                       
                                    </table>
        
                                    <?php if($data['order']->payment_method != 'cod'): ?>
                                    <div style="padding-top: 10px; text-align: right;">
                                        <span style="font-size: 16px; color: #388e3c;">
                                            Payment Completed <i class="fa fa-check" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                    <?php endif; ?>
                                    
                                  
                                                                   
                                </div>
                                
                            </div>

                            <div class="row wishlist-basic-padding" style="padding-top: 0;"></div>

                        <div class="account-menu-break" id="CartBreak2"></div>      
                         
                         
                    </form>
                    </div> 
                    
                </div>
        
            </div>
        </div>
      
        </div>
    </div>





    <div class="container">
    <div class="row">
    <div class="col-md-12">
    <div class="account-details-container">
        <div class="right-wishlist-container" style="min-height: unset;">
    
            <div class="wishlist-basic-padding">
                <div class="account-details-title" style="padding-bottom: 0px;">
                    <span>Items Ordered (<?php echo e($data['items']->count()); ?>)</span>
                </div>
            </div>
    
            <div class="account-menu-break"></div>   
                                                
                <div class="wishlist-container">   
                    <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="account-menu-break"></div>     
                            <div class="row wishlist-basic-padding" style="padding-bottom: 0;">
                                <div class="col-md-3">
                                    <a href="http://localhost:8000/product/<?php echo e($item->id); ?>" target="_blank">
                                        <div class="wish-product-image-container">
                                            <img src="http://localhost:8000/storage/images/products/<?php echo e($item->image->image); ?>" alt="">
                                        </div>
                                    </a>
                                </div>
    
                                <div class="col-md-8">
                                    <a href="http://localhost:8000/product/2" target="_blank">
                                        <span class="wish-product-title font-weight-500 color-0066c0"><?php echo e($item->product->product_name); ?></span>
                                    </a>
                                    <p>
                                        <div class="details-price" style="margin-bottom: 0;">
                                                <span style="font-weight: normal; font-size: 15px;">Unit Price: <span style="font-weight: 500;"><font class="rupees">₹</font> <?php echo e(moneyFormatIndia($item->unit_price)); ?></span></span><br>
                                                <span style="font-weight: normal; font-size: 15px;">Qty: <span style="font-weight: 500;"> <?php echo e($item->qty); ?></span></span><br>
                                                <span style="font-weight: normal; font-size: 15px;">Total Price: <span style="font-weight: 500;"><font class="rupees">₹</font> <?php echo e(moneyFormatIndia($item->total_price)); ?></span></span>
                                            
                                        </div>
                                    </p>
                                </div>

                            </div>

                            <div class="row wishlist-basic-padding" style="padding-top: 0;"></div>

                        <div class="account-menu-break" id="CartBreak2"></div>      
           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> 
                    
                </div>
        
            </div>
        </div>
      
        </div>
    </div>







</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/checkout/success.blade.php ENDPATH**/ ?>