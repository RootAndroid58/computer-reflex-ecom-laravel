

<?php $__env->startSection('title', 'Products Search'); ?>
    


<?php $__env->startSection('content'); ?>


<div class="shop-page-wrapper shop-page-padding ptb-50">
    <div class="container-fluid">
        <div id="RowDiv">
        <div class="row">

            
            <div class="col-lg-2">
                <div class="shop-sidebar mr-50">
                 <form method="GET" action="<?php echo e(route('show-catalog', $catalog->slug)); ?>" id="filter_form">
                   
                    <input type="hidden" name="search" value="<?php echo e(request()->search); ?>">
                    <div class="sidebar-widget mb-45">
                        <h3 class="sidebar-title">Filter By Category</h3>
                        <div class="sidebar-categories">
                           <div class="form-group">
                             <select class="" name="category" id="" style="height: 30px; cursor: pointer;" >
                               <option value="all">All</option>
                               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($category->category); ?>" <?php if($category->category == request()->category): ?> selected <?php endif; ?>><?php echo e($category->category); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                           </div>
                        </div>
                    </div>
            
                    <div class="sidebar-widget mb-40">
                        <h3 class="sidebar-title">Filter by Price</h3>
                        <div class="price_filter">
                            <div class="price_slider_amount">
                                <div class="_2b0bUo">
                                    <div class="_1YAKP4">
                                        <input type="number" name="min_price" class="_2YxCDZ" value="<?php echo e(request()->min_price ?? '0'); ?>">
                                        <small id="helpId" class="form-text text-muted">Min Price</small>
                                    </div>

                                        <div class="_3zohzR">To</div>
                                    
                                        <div class="_3uDYxP">
                                            <input type="number" name="max_price" class="_2YxCDZ" value="<?php echo e(request()->max_price ?? ''); ?>">
                                            <small id="helpId" class="form-text text-muted">Max Price</small>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="sidebar-widget mb-40">
                        <h3 class="sidebar-title">Availability</h3>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="stock" value="checked" id="flexCheckDefault" <?php if(request()->stock == 'checked'): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                    Show Out Of Stock Items
                                </label>
                            </div>
                    </div>
                    <button type="submit" class="btn btn-dark">Apply Filter</button>
                    </form>
                </div>
            </div>
            






            <div class="col-lg-10">
                <div class="shop-product-wrapper res-xl">
                    <div class="shop-bar-area">



                        <div class="shop-bar pb-60">
                            <div class="shop-found-selector">
                                <div class="shop-found">
                                    <p><span><?php echo e($ProductsCount); ?></span> Products Found</p>
                                </div>
                                <div class="shop-selector">
                                    <label>Sort By : </label>
                                    <select name="select">
                                        <option value="">Default</option>
                                        <option value="">A to Z</option>
                                        <option value=""> Z to A</option>
                                        <option value="">In stock</option>
                                    </select>
                                </div>
                            </div>
                            <div class="shop-filter-tab">
                                <div class="shop-tab nav" role=tablist>
                                    <a class="active" href="#grid-sidebar3" data-toggle="tab" role="tab" aria-selected="false">
                                        <i class="ti-layout-grid4-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>



                        <div class="shop-product-content tab-content">
                            <div id="grid-sidebar3" class="tab-pane fade active show">
                                <div class="row">

                                    
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 col-xl-3">             
                                        <div class="product-wrapper mb-30">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('product-index', $product->id)); ?>" target="_blank">
                                                    <div class="sm-prod-img-container prod-back-div" style="background-image: url('<?php echo e(asset('storage/images/products/'.$product->images[0]->image)); ?>');"></div>
                                                </a>
                                                <div class="product-action">
                                                    <a class="animate-left cursor-pointer" onclick="ToggleWishlist(<?php echo e($product->id); ?>)" title="Wishlist"><i class="pe-7s-like"></i></a>
                                                    <a class="animate-top cursor-pointer" onclick="ToogleCart(<?php echo e($product->id); ?>)" title="Add To Cart"><i class="pe-7s-cart"></i></a>
                                                    <a class="animate-right cursor-pointer" onclick="ToggleCompare(<?php echo e($product->id); ?>)" title="Compare"><i class="pe-7s-repeat"></i></a>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h4><a class="line-limit-3" href="<?php echo e(route('product-index', $product->id)); ?>"> <?php echo e($product->product_name); ?> </a></h4>
                                                <span><font class="rupees">₹</font> 
                                                    <?php echo e(moneyFormatIndia($product->product_price)); ?>

                                                    <b style="font-size: 17px; color: #388e3c; font-weight: 500;"><?php echo e(((($product->product_mrp - $product->product_price) / $product->product_mrp)*100)%100); ?>% off</b>
                                                </span>
                                                <?php if($product->product_stock <= 0): ?>
                                                    <br>
                                                    <span class="text-danger">Out Of Stock</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
        
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                
                    <div>
                        <?php echo e($products->links('pagination::bootstrap-4')); ?>

                    </div>

            </div>
        </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('bottom-js'); ?>
<script>

function ToggleCompare(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-compare-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {
        if (data.status == 500 || data.status == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl(data.msg, {
                type: data.type,
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}


function ToggleWishlist(product_id) {

$.ajax({
    url: "<?php echo e(route('toggle-wishlist-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 500) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed from wishlist.", {
                type: "danger",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 200) {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added to wishlist.", {
                type: "success",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}

function ToogleCart(product_id) {

    $.ajax({
    url: "<?php echo e(route('toggle-cart-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 200) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Added To Cart.", {
                type: "success",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        } else if(data == 500) {
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Removed From Cart.", {
                type: "danger",
                offset: {from:"bottom", amount: 100},
                align: 'center',
                allow_dismis: true,
                stack_spacing: 10,
            })
        }
    }
})

}


$('#ToggleCartBtn').click(function (e) {

e.preventDefault()

var product_id  = $('input[name="product_id"]').val()

console.log(product_id)

$.ajax({
    url: "<?php echo e(route('toggle-cart-btn')); ?>",
    method: 'POST',
    data: {
        'product_id' : product_id,
    },
    success: function (data) {

        if (data == 200) {
            console.log('Added to cart')
            $('#ToggleCartBtn').html('remove from cart')
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
        } else if(data == 500) {
            $('#ToggleCartBtn').html('add to cart')
            $('#CartCount').load("<?php echo e(route('cart')); ?> #CartCount")
        }
    }
})
})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/catalog-products.blade.php ENDPATH**/ ?>