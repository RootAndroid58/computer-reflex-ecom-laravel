    

<?php 
$UserName=str_word_count(Auth()->user()->name, 1); 
?>
<?php $__env->startSection('title', 'Order Placed'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="body-container" id="CartContainer">
    <div class="container">
        <div class="row">
        <div class="col-md-12">
        <div class="account-details-container">
            <div class="right-wishlist-container" style="min-height: 0;">
        
                <div class="wishlist-basic-padding" style="padding: 10px 32px;">
                    <div class="account-details-title" style="padding-bottom: 0px;">
                        <img src="<?php echo e(asset('/img/svg/gift-box.svg')); ?>" width="50" alt="" srcset="">
                        <span style="padding-right: 0;"><?php echo e($UserName[0]); ?>'s Orders</span>
                    </div>
                </div>
        
                <div class="account-menu-break"></div>   
                                                
                    <div class="wishlist-container">        
                        <div class="account-menu-break"></div>     
                     
                        <?php if($orders->count() == 0): ?>
                            <div class="wishlist-basic-padding" >
                                <div class="w-100">
                                    <div class="blank-wishlist-container text-center">
                                        <div class="blank-wishlist-img-container" style="margin-top: 50px;">
                                            <img class="img-nodrag" style="max-width: 25%" src="<?php echo e(asset('img/svg/empty-cart.svg')); ?>">
                                        </div>
                                        <div class="blank-wishlist-txt-container text-center mb-3" style="margin-top: 30px;">
                                            <span style="font-weight: 500; font-size: 20px;">No Orders!</span>
                                            <br>
                                            <span>You have no orders on your account.</span>
                                            
                                        </div>
                                        <a href="<?php echo e(route('home')); ?>" class="btn btn-dark btn-lg">Start Shopping!</a>
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                            

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="wishlist-basic-padding orders-header" >
                                <div class="row " style="color: black;">
                                    <div class="col-5 ">
                                        <span>Order <a style="color: #0066c0;" href="<?php echo e(route('order-page', $order->id)); ?>">#<?php echo e(date_format($order->created_at,"Y-mdHis").'-'.$order->id); ?></a></span>

                                    <?php if($order->status == 'payment_pending'): ?> 
                                        <span style="color: #f6c23e">
                                            (Payment Pending.)
                                        </span>
                                    <?php elseif($order->status == 'order_placed'): ?> 
                                        <span style="color: #2874f0">
                                            (Order Placed.)
                                        </span>
                                    <?php elseif($order->status == 'payment_failed'): ?> 
                                        <span style="color: #ff6161">
                                            (Payment Declined.)
                                        </span>
                                    <?php endif; ?>
                                    </div>
                                    <div class="col-3 ">
                                        <span>Order Placed: <span style="font-weight: 500;"><?php echo e(date_format($order->created_at,"dS M, Y (D)")); ?></span></span>
                                    </div>
                                    <div class="col-4" style="text-align: right;">
                                        <span>Total: <span style="font-weight: 500;"><font class="rupees">₹</font><?php echo e(moneyFormatIndia($order->price)); ?></span><?php if($order->payment_method == 'cod'): ?> (Cash On Delivery) <?php elseif($order->payment_method == 'paytm'): ?> (PayTM) <?php elseif($order->payment_method == 'payu'): ?> (PayU) <?php endif; ?></span>
                                    </div>
                                </div>
                            </div>
                            
                            <?php $__currentLoopData = $order->OrderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="wishlist-basic-padding" style="padding-bottom: 0;">
                                <div class="row">
                                    <div class="col-md-2">
                                        <a href="http://localhost:8000/product/<?php echo e($item->product->id); ?>" target="_blank">
                                            <div class="wish-product-image-container">
                                                <img src="http://localhost:8000/storage/images/products/<?php echo e($item->image->image); ?>" alt="">
                                            </div>
                                        </a>
                                    </div>
        
                                    <div class="col-md-5">
                                        <a href="http://localhost:8000/product/1" target="_blank">
                                            <span class="wish-product-title font-weight-500 color-0066c0"><?php echo e($item->product->product_name); ?></span>
                                        </a>
                                    </div>

                                    <div class="col-3">
                                        <table style="width: 100%">
                                            <tr style="width: 100%">
                                                <td style="width: 50%">Unit Price:</td>
                                                <td style="width: 50%"><font class="rupees">₹</font><?php echo e(moneyFormatIndia($item->unit_price)); ?></td>
                                            </tr>
                                            <tr style="width: 100%">
                                                <td style="width: 50%">Qty:</td>
                                                <td style="width: 50%"><?php echo e(moneyFormatIndia($item->qty)); ?></td>
                                            </tr>
                                            <tr style="width: 100%">
                                                <td style="width: 50%">Total:</td>
                                                <td style="width: 50%"><font class="rupees">₹</font><?php echo e(moneyFormatIndia($item->total_price)); ?></td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="col-md-2">
                                        <?php if($item->status == 'order_placed'): ?>
                                        <span style="color: #2874f0">
                                            <span style="">
                                                <i class="fa fa-circle" aria-hidden="true"></i>
                                            </span>
                                            Order Placed.
                                        </span>
                                        <?php elseif($item->status == 'packing_started'): ?>
                                        <span style="color: #2874f0">
                                            <span style="">
                                                <i class="fa fa-circle" aria-hidden="true"></i>
                                            </span>
                                            Packing Started.
                                        </span>
                                        <?php elseif($item->status == 'packing_completed'): ?>
                                        <span style="color: #2874f0">
                                            <span style="">
                                                <i class="fa fa-circle" aria-hidden="true"></i>
                                            </span>
                                            Packing Completed.
                                        </span>
                                        <?php elseif($item->status == 'shipment_created'): ?>
                                        <span style="color: #2874f0">
                                            <span style="">
                                                <i class="fa fa-circle" aria-hidden="true"></i>
                                            </span>
                                            Shipment Created, Waiting For Pickup.
                                        </span>
                                        <?php elseif($item->status == 'item_shipped'): ?>
                                        <span style="color: #2874f0">
                                            <span style="">
                                                <i class="fa fa-circle" aria-hidden="true"></i>
                                            </span>
                                            Product Shipped Via <b><?php echo e($item->shipment->courier_name); ?></b>.<br>
                                          
                                                Delivery By: <b><?php echo e(date_format(new DateTime($item->delivery_date), "dS M,(D)")); ?></b>
                                        
                                        </span>
                                        <?php elseif($item->status == 'item_delivered'): ?>
                                        <span style="color: #28a745">
                                            <span style="">
                                                <i class="fa fa-circle" aria-hidden="true"></i>
                                            </span>
                                            Delivered On: <b><?php echo e(date_format(new DateTime($item->delivery_date), "dS M,(D)")); ?></b>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <div class="row wishlist-basic-padding" style="padding-top: 0;"></div>
                                  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> 
                       
                        
                    </div>
            
                </div>
            </div>
          
            </div>
        </div>
    
    
    



</div>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/orders.blade.php ENDPATH**/ ?>