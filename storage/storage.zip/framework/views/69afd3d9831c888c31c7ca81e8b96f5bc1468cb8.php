

<?php $__env->startSection('nav-manage-products', 'active'); ?>
<?php $__env->startSection('title','Edit Product'); ?>

<?php $__env->startSection('css-js'); ?>
<style>
    .tagit{
        height: 40vh;
        border-radius: 10px;
        border-color: black;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid">

<h3>Edit Product &nbsp;<a class="btn btn-primary btn-sm float-right" href="<?php echo e(route('edit-product-images', $product->id)); ?>">Edit Images</a></h3>

<?php if(Session::has('ProductEdited')): ?>
    <div class="alert alert-success" id="admin_user_created_alert" role="alert">
        Product edited successfully.
    </div>
<?php endif; ?>


        <div class="container" style="margin-bottom: 100px;">
            
        <form action="<?php echo e(route('edit-product-submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

            <div class="row">
                <div class="col-9">
                    <div class="form-group">
                        <label class="text-dark">Product Name</label>
                        <input name="product_name" class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Name of the product you wanna list." value="<?php echo e(old('product_name') ?? $product->product_name); ?>" required>
                        <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                      <label for="product_status">Status</label>
                      <select class="form-control" name="product_status" id="product_status" required>
                        <option value="0" <?php if($product->product_status == 0): ?> selected <?php endif; ?>>Inactive</option>
                        <option value="1" <?php if($product->product_status == 1): ?> selected <?php endif; ?>>Active</option>
                      </select>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-3">
                    <div class="form-group">
                        <label class="text-dark">Product MRP (INR)</label>
                        <input name="product_mrp" id="product_mrp" class="form-control <?php $__errorArgs = ['product_mrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="&#8377; Product MRP (INR)." value="<?php echo e($product->product_mrp); ?>" required>
                        <small class="text-muted" id="sHelpText">MRP printed on product.</small>
                        <?php $__errorArgs = ['product_mrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>            
                <div class="col-3">
                    <div class="form-group">
                        <label class="text-dark">Selling Price (INR)</label>
                        <input name="product_price" id="product_price" class="form-control <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="&#8377; Selling Price (INR)." value="<?php echo e($product->product_price); ?>" required>
                        <small class="text-muted" id="sHelpText">Selling Price.</small>
                        <div class="invalid-feedback">Selling price can't be greater than MRP!</div>
                        <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>            
                <div class="col-3">
                    <div class="form-group">
                        <label class="text-dark">Discount (%)</label>
                        <input id="discount" class="form-control" placeholder="% Discount." readonly>
                        <small class="text-muted" id="sHelpText">Discount auto calculated.</small>
                        <div class="invalid-feedback">Selling price can't be greater than MRP!</div>
                    </div>
                </div> 
                <div class="col-3">
                    <div class="form-group">
                      <label for="product_stock">Stock</label>
                      <input type="number" class="form-control" name="product_stock" id="product_stock" value="<?php echo e($product->product_stock); ?>" required>
                      <small id="helpId" class="form-text text-muted">Enter <b>0</b> for No Stock</small>
                    </div>
                </div>           
            </div>




            <table  class="table table-hover small-text" id="tb2">
                <tr class="tr-header">
                    <td class="text-center"><strong>Specification</strong></td>
                    <td class="text-center"><strong>Value</strong></td>     
                    <td> <a href="javascript:void(0);" class="btn btn-primary btn-sm float-right" id="addMore2" title="Add More Person">Add More &nbsp;<i class="fa fa-plus-square"></i></a></td>     
                </tr>

                <?php if($specifications->count() < 1): ?>
                <tr>
                    <td>
                        <div class="form-group">
                            <input name="key[]" class="form-control <?php $__errorArgs = ['key[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Specification Name" value="" required>
                            <?php $__errorArgs = ['key[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input name="value[]" class="form-control <?php $__errorArgs = ['value[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Specification Value"  value="" required>
                            <?php $__errorArgs = ['value[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </td>
                    <td>
                        <a class="btn btn-danger btn-sm remove">&nbsp;<i class="fa fa-times"></i>&nbsp;</a>
                    </td>
                    <hr>
                </tr>
                <?php endif; ?>

                <?php $__currentLoopData = $specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="form-group">
                            <input name="key[]" class="form-control <?php $__errorArgs = ['key[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Specification Name" value="<?php echo e(old('key[]') ?? $specification->specification_key); ?>" required>
                            <?php $__errorArgs = ['key[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <input name="value[]" class="form-control <?php $__errorArgs = ['value[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Specification Value"  value="<?php echo e(old('value[]') ?? $specification->specification_value); ?>" required>
                            <?php $__errorArgs = ['value[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </td>
                    <td>
                        <a class="btn btn-danger btn-sm remove">&nbsp;<i class="fa fa-times"></i>&nbsp;</a>
                    </td>
                    <hr>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>








            <div class="form-group">
                <label class="text-dark">Short Description</label>
                <textarea name="product_description" id="description" class="form-control <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Product description." rows="7"></textarea>
                <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label class="text-dark">Detailed Description</label>
                <textarea name="product_long_description" id="long_description" class="form-control <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Product description." rows="7"></textarea>
                <?php $__errorArgs = ['product_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>



            <hr>




            <ul id="myTags">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($tag->product_tag); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           


            <button type="submit" class="btn btn-primary float-right">Save Changes</button>
        </form>

    </div>


            



<div class="d-none" id="prefilledDescription"><?php echo $product->product_description; ?></div>
<div class="d-none" id="prefilledLongDescription"><?php echo $product->product_long_description; ?></div>


</div> <!--Container-Fluid End-->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>

<script>
    $(function(){
        $('#addMore2').on('click', function() {
                var data = $("#tb2 tr:eq(1)").clone(true).appendTo("#tb2");
                data.find("input").val('');
        });
        $(document).on('click', '.remove', function() {
            var trIndex = $(this).closest("tr").index();
                if(trIndex>1) {
                $(this).closest("tr").remove();
            } else {
                
            }
        });
    });    
</script>


<script>
    $(document).ready(function() {

        // Description
        $('#description').summernote({
        toolbar: [
        ['color', ['color']],
        ['style', ['bold', 'italic', 'underline', 'clear', ]],
        ['view', ['codeview']],
        ['para', ['ul', 'ol']],
        ['table', ['table']],
    ],
            minHeight: 220,         // set minimum height of editor
            maxHeight: 500,         // set maximum height of editor
            focus: true,    
        }).summernote('code', $('#prefilledDescription').html()); 

        // Long Description
        $('#long_description').summernote({
        toolbar: [
        ['color', ['color']],
        ['para', ['ul', 'ol']],
        ['table', ['table']],
        ['style', ['bold', 'italic', 'underline', 'clear', ]],
        ['insert', ['link', 'picture', 'video']],
        ['view', ['codeview']]
    ],
            minHeight: 220,         // set minimum height of editor
            maxHeight: 500,         // set maximum height of editor
            focus: true,    
        }).summernote('code', $('#prefilledLongDescription').html()); 


    });
</script>


<script>
    $(document).ready(function(){
        $(document).on('mouseover mouseout keyup','body *',function() {
        var m = parseInt($('#product_mrp').val()); 
        var s = parseInt($('#product_price').val());
        var perc="";

        if (s>m) {
            $('#discount').val('')
            $('#discount').addClass('is-invalid')
            $('#sHelpText').addClass('d-none')
            $('#product_price').addClass('is-invalid')
        } else {
            $('#discount').removeClass('is-invalid')
            $('#sHelpText').removeClass('d-none')
            $('#product_price').removeClass('is-invalid')
            if(isNaN(m) || isNaN(s)){
                perc="";
            } else { 
            perc = (((m - s)/m)*100).toFixed(0);
           }
           $('#discount').val(perc+'%');
        }
        })
        })
</script>


<script>
        $(document).ready(function() {
            $("#myTags").tagit({
                fieldName: "tags[]",
                autocomplete: false,
                allowSpaces: true,
            });
            
        });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/edit-product.blade.php ENDPATH**/ ?>