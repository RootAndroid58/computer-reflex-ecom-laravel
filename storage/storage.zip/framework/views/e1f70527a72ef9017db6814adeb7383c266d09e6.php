

<?php $__env->startSection('nav-manage-ui', 'active'); ?>
<?php $__env->startSection('title','Publish Banners'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid">

<h3>Publish Banners</h3>

<?php if(Session::has('ChangesPublished')): ?>
<div class="alert alert-success" role="alert">Changes successfully published!</div>
<?php endif; ?>
<form action="<?php echo e(route('admin-publish-banners-submit')); ?>" method="post" style="max-width: 650px; margin-left: auto; margin-right: auto;">
    <?php echo csrf_field(); ?>
<div class="row">
    <div class="col-md-6">

        <div class="form-group">
            <label >Banner Position: <strong>1</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_1">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 1): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>2</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_2">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 2): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>3</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_3">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 3): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>4</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_4">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 4): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>5</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_5">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 5): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
    </div>
    

    <div class="col-md-6">

        <div class="form-group">
            <label >Banner Position: <strong>6</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_6">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 6): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>7</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_7">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 7): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>8</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_8">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 8): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>9</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_9">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 9): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>
    
        <div class="form-group">
            <label >Banner Position: <strong>10</strong></label>
            <select class="custom-select my-1 mr-sm-2" name="banner_10">
                <option value="">No Banner</option>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <option value="<?php echo e($banner->id); ?>" <?php if($banner->banner_position == 10): ?> selected <?php endif; ?>><?php echo e($banner->banner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        </div>

    </div>

</div>

<i class="fa fa-lightbulb-o" style="color: rgb(255, 187, 0);"></i> Simply choose "No Banner" if you don't want any banner in that position.

<div class="row float-right">
    <button type="submit" class="btn btn-success btn-sm">Publish Changes <i class="fa fa-check" aria-hidden="true"></i></button>
</div>

</form>

<br><br>
<?php if($errors->any()): ?>
        <div class="alert alert-danger " role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php endif; ?>

</div> <!--Container-Fluid End-->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/publish-banners.blade.php ENDPATH**/ ?>