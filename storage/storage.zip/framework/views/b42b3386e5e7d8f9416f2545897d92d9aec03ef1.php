

<?php $__env->startSection('nav-manage-ui', 'active'); ?>
<?php $__env->startSection('title','Edit Banner'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid"><div id="container">

<h3>Edit Banner</h3>

<?php if(Session::has('updated')): ?>
<div class="alert alert-success" role="alert">
    <strong>Banner Updated Successfully.</strong>
</div>

<?php endif; ?>

<form action="<?php echo e(route('admin-edit-banner-submit')); ?>" method="POST" enctype="multipart/form-data" style="max-width: 650px; margin-left: auto; margin-right: auto;">

    <?php echo csrf_field(); ?>
    <input type="hidden" name="banner_id" value="<?php echo e($banner->id); ?>">
    <div class="form-group">
        <label>Banner Name <font color='red'>*</font></label>
        <input type="text" name="banner_name" class="form-control <?php $__errorArgs = ['banner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banner Name" value="<?php echo e(old('banner_name') ?? $banner->banner_name); ?>">
        <?php $__errorArgs = ['banner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label>Banner Header <font color='red'>*</font></label>
        <input type="text" name="banner_header" class="form-control <?php $__errorArgs = ['banner_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banner Header" value="<?php echo e(old('banner_header') ?? $banner->banner_header); ?>">
        <?php $__errorArgs = ['banner_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label>Banner Header Line 2 <font color='red'>*</font></label>
        <input type="text" name="banner_header_2" class="form-control <?php $__errorArgs = ['banner_header_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banner Header Line 2" value="<?php echo e(old('banner_header_2') ?? $banner->banner_header_2); ?>">
        <?php $__errorArgs = ['banner_header_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label>Banner Caption <font color='red'>*</font></label>
        <input type="text" name="banner_caption" class="form-control <?php $__errorArgs = ['banner_caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banner Caption" value="<?php echo e(old('banner_caption') ?? $banner->banner_caption); ?>">
        <?php $__errorArgs = ['banner_caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span> 
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-row">
        <div class="form-group col">
            <label>Banner Button Text <font color='red'>*</font></label>
            <input type="text" name="banner_btn_txt" class="form-control <?php $__errorArgs = ['banner_btn_txt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banner Button Text" value="<?php echo e(old('') ?? $banner->banner_btn_txt); ?>">
            <?php $__errorArgs = ['banner_btn_txt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback"><?php echo e($message); ?></span> 
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col">
            <label>Banner Button Link <font color='red'>*</font></label>
            <input type="text" name="banner_btn_link" class="form-control <?php $__errorArgs = ['banner_btn_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banner Button Text" value="<?php echo e(old('banner_btn_link') ?? $banner->banner_btn_link); ?>">
            <?php $__errorArgs = ['banner_btn_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback"><?php echo e($message); ?></span> 
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-check mb-3">
      <label class="form-check-label cursor-pointer">
        <input type="checkbox" class="form-check-input cursor-pointer" id="image-upload-checkbox" value="checked">Edit Banner Image
      </label>
    </div>
    
    <div id="image-uploader-container" class="form-group">
        
    </div>

      <button type="submit" class="btn btn-success">Edit Banner</button>
</form>



</div></div> <!--Container-Fluid End-->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>
<script>
    $('#image-uploader-container').html()

    $('#image-upload-checkbox').on('change', function () {
       var fieldHtml =  `
                            <label>New Banner Image <font color='red'>*</font></label>
                            <input type="file" name="banner_img" class="form-control-file" >
                        `
        if ($(this).prop('checked')) {
            $('#image-uploader-container').html(fieldHtml)
        } 
        else {
            $('#image-uploader-container').html('')
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/edit-banner-page.blade.php ENDPATH**/ ?>