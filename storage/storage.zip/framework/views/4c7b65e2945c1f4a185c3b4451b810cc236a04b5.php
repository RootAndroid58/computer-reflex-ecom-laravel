

<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('modals'); ?>
<div id="AddAddressModalDiv">
    <div class="modal fade" id="AddAddressModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Address (India Only)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>

           <div class="modal-body">
               <form id="AddAddressForm" style="width: 100%"> <?php echo csrf_field(); ?>
                    <div class="row w-100">
                        <div class="col-12">
                            <div class="form-group">
                            <label for="NewAddressName">Receiver's Name <font color="red">*</font></label>
                            <input autocomplete="name" required name="name"  type="text" id="NewAddressName" class="form-control" placeholder="i.e Jarvis" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                            <label for="NewAddressHouse">House No. / Apt. <font color="red">*</font></label>
                            <input required name="house" type="text" id="NewAddressHouse" class="form-control" placeholder="Stark Tower" >
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                            <label for="NewAddressLocality">Locality <font color="red">*</font></label>
                            <input autocomplete="street-address" required name="locality" type="text" id="NewAddressLocality" class="form-control" placeholder="i.e 200 Park Ave">
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressCity">City/Town <font color="red">*</font></label>
                                <input autocomplete="locality" required name="city" type="text" id="NewAddressCity" class="form-control" placeholder="i.e Midtown Manhattan" >
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressDistrict">District <font color="red">*</font></label>
                                <input required name="district" type="text" id="NewAddressDistrict" class="form-control" placeholder="i.e New York" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressState">State <font color="red">*</font></label>
                                <input required name="state" type="text" id="NewAddressState" class="form-control" placeholder="i.e New York" >
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressPin">Postal PIN Code <font color="red">*</font></label>
                                <input autocomplete="postal-code" required name="pin_code" type="text" id="NewAddressPin" class="form-control" placeholder="Postal PIN Code" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressMobile">Mobile Number <font color="red">*</font></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">+91</span>
                                    </div>
                                    <input autocomplete="tel-local" required name="mobile" type="text" id="NewAddressMobile" class="form-control" placeholder="10-Digit Mobile Number" >
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressAltMobile">Alternate Mobile</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">+91</span>
                                    </div>
                                    <input autocomplete="tel-local" name="altMobile" type="text" id="NewAddressAltMobile" class="form-control" placeholder="Optional" >
                                </div>
                            </div>
                        </div>
                    </div>
                </form> 
           </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
                <button type="submit" form="AddAddressForm" class="btn btn-primary">ADD ADDRESS</button>
              </div>
        </div>
        </div>
    </div>  
</div>


<div id="EdiAddressModalDiv">
    <div class="modal fade" id="EditAddressModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Addres (India Only)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
           <div class="modal-body">
               <form id="EditAddressForm" style="width: 100%"> <?php echo csrf_field(); ?> <input type="hidden" name="address_id" value="">
                    <div class="row w-100">
                        <div class="col-12">
                            <div class="form-group">
                            <label for="NewAddressName2">Receiver's Name <font color="red">*</font></label>
                            <input autocomplete="name" required name="name"  type="text" id="NewAddressName2" class="form-control" placeholder="i.e Jarvis" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                            <label for="NewAddressHouse2">House No. / Apt. <font color="red">*</font></label>
                            <input required name="house" type="text" id="NewAddressHouse2" class="form-control" placeholder="Stark Tower" >
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                            <label for="NewAddressLocality2">Locality <font color="red">*</font></label>
                            <input autocomplete="street-address" required name="locality" type="text" id="NewAddressLocality2" class="form-control" placeholder="i.e 200 Park Ave" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressCity2">City/Town <font color="red">*</font></label>
                                <input autocomplete="locality" required name="city" type="text" id="NewAddressCity2" class="form-control" placeholder="i.e Midtown Manhattan" >
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressDistrict2">District <font color="red">*</font></label>
                                <input required name="district" type="text" id="NewAddressDistrict2" class="form-control" placeholder="i.e New York" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressState2">State <font color="red">*</font></label>
                                <input required name="state" type="text" id="NewAddressState2" class="form-control" placeholder="i.e New York" >
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressPin2">Postal PIN Code <font color="red">*</font></label>
                                <input autocomplete="postal-code" required name="pin_code" type="text" id="NewAddressPin2" class="form-control" placeholder="Postal PIN Code" >
                            </div>
                        </div>
                    </div>
                    <div class="row w-100">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressMobile2">Mobile Number <font color="red">*</font></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">+91</span>
                                    </div>
                                    <input autocomplete="mobile" required name="mobile" type="text" id="NewAddressMobile2" class="form-control" placeholder="10-Digit Mobile Number" >
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="NewAddressAltMobile2">Alternate Mobile</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">+91</span>
                                    </div>
                                    <input autocomplete="mobile" name="altMobile" type="text" id="NewAddressAltMobile2" class="form-control" placeholder="Optional" >
                                </div>
                            </div>
                        </div>
                    </div>
                </form> 
           </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
                <button type="submit" form="EditAddressForm" class="btn btn-primary">SAVE CHANGES</button>
              </div>
        </div>
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>



    








<?php $__env->startSection('content'); ?>

    <div class="body-container" id="CartContainer">
        <div class="container">
        <div class="row">
            
            
            <div class="col-md-9 d-none display-pages-section" id="OrderSummarySection">
                <div class="account-details-container">
                    <div class="right-wishlist-container"  style="min-height: 80vh;">
                        <div class="wishlist-basic-padding">
                            <div class="account-details-title" style="padding-bottom: 0px;">
                                <span>Order Summary</span>
                            </div>
                        </div>
                        <div class="account-menu-break"></div>   
                        
                                <?php if(!isset($data)): ?>
                                <div class="wishlist-container">
                                    <div class="wishlist-basic-padding">
                                        <div class="w-100"  >
                                            <div class="blank-wishlist-container text-center">
                                                <div class="blank-wishlist-img-container" style="margin-top: 50px;">
                                                    <img class="img-nodrag" style="max-width: 35%" src="<?php echo e(asset('img/svg/blank-cart.png')); ?>">
                                                </div>
                                                <div class="blank-wishlist-txt-container text-center" style="margin-top: 30px;">
                                                    <span style="font-weight: 500; font-size: 20px;">Empty Cart!</span>
                                                    <br>
                                                    <span>No Items To Checkout!</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <?php else: ?>
                            
            <div class="wishlist-container">   
                <form id="CheckoutForm" method="POST" action="<?php echo e(route('checkout-submit')); ?>"> <?php echo csrf_field(); ?>
                <input type="hidden" name="payment_method" required>
                <input type="hidden" name="address_id" required>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$item->product_stock <= 0): ?> 
                
                <?php $StockCounter = 1; ?>

                                        <div class="row wishlist-basic-padding" id="CartItem<?php echo e($item->id); ?>" style="padding-bottom: 0;">
                                            <div class="col-md-3">
                                                <a href="http://localhost:8000/product/<?php echo e($item->id); ?>" target="_blank">
                                                    <div class="wish-product-image-container">
                                                        <img src="<?php echo e(asset('storage/images/products/'. $item->images[0]->image )); ?>" alt="">
                                                    </div>
                                                </a>
                                            </div>
                                            
                                            <div class="col-md-8">
                                                <a href="http://localhost:8000/product/<?php echo e($item->id); ?>" target="_blank">
                                                    <span class="wish-product-title font-weight-500 color-0066c0"><?php echo e($item->product_name); ?></span>
                                                </a>
                                                
                                                <div class="details-price" style="margin-bottom: 0;">
                                                    <span class="text-muted" style="font-size: 15px;"><font class="rupees"><s>₹</s></font><s> <span id="MRPField<?php echo e($item->id); ?>"><?php echo e(moneyFormatIndia($item->product_mrp * $qty[$key])); ?></s></span></span>
                                                    <br>
                                                    <span><font class="rupees" style="font-size: 18px">₹</font> <span style="font-size: 18px;"><span id="PriceField<?php echo e($item->id); ?>"><?php echo e(moneyFormatIndia($item->product_price * $qty[$key])); ?></span></span> 
                                                        <b style="font-size: 15px; color: #388e3c; font-weight: 500;"> 
                                                            <?php echo e(((($item->product_mrp - $item->product_price) / $item->product_mrp)*100)%100); ?>% off
                                                        </b>  
                                                    </span>
        
                                                    <?php if($item->product_stock <= 0): ?>
                                                        <p class="text-danger" style="font-weight: 500;"></i>Out of stock!</p>
                                                    <?php else: ?>
                                                    <div class="input-group input-group-sm" style="max-width: 160px;">
                                                        <div class="input-group-prepend">
                                                        <label class="input-group-text" for="product-quantity">Qty</label>
                                                        </div>
                                                        <input type="hidden" class="product_ids" name="product_id[]" id="" value="<?php echo e($item->id); ?>">
                                                        <select name="product_qty[]" class="custom-select qtys" id="product-quantity-<?php echo e($item->id); ?>" onchange="ChangeQty('<?php echo e($item->id); ?>')">
                                                        <?php while($StockCounter <= $item->product_stock): ?>
                                                            <option <?php if($qty[$key] == $StockCounter): ?> selected <?php endif; ?> value="<?php echo e($StockCounter); ?>"><?php echo e($StockCounter); ?></option>
                                                            <?php echo e($StockCounter++); ?>

                                                        <?php endwhile; ?>
                                                        </select>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        
                                    </div>
                                    
        
                                        <div class="row wishlist-basic-padding" style="padding-top: 0;"></div>
        
                                    <div class="account-menu-break" id="CartBreak<?php echo e($item->id); ?>"></div>      
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </form>
                                
                                </div> 
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    


 
    <div class="col-md-9 display-pages-section" id="AddressSection">
        <div id="OrderSummaryDIV">
        <div id="addresses-container-div">
            <div class="account-details-container">
                <div class="right-account-container ">
                    <div class="account-details-title">
                        <span>Delivery Address</span>
                    </div>

                    <div class="wishlist-container">
                        <div class="add-address-box-wrapper">
                            <a href="#AddAddress" data-toggle="modal" data-target="#AddAddressModal">
                                <div class="add-address-box">
                                    <img src="<?php echo e(asset('img/svg/times.svg')); ?>" alt="" srcset="">
                                    <span>ADD A NEW ADDRESS</span>
                                </div>
                            </a>
                        </div>
                        <div>
                            
                            <?php if( !isset($addresses[0])): ?>
                                <div class="wishlist-container">
                                    <div class="wishlist-basic-padding">
                                        <div class="w-100"  >
                                            <div class="blank-wishlist-container text-center">
                                                <div class="blank-wishlist-img-container" style="margin-top: 50px;">
                                                    <img class="img-nodrag" style="max-width: 35%" src="<?php echo e(asset('img/svg/no-address.svg')); ?>">
                                                </div>
                                                <div class="blank-wishlist-txt-container text-center" style="margin-top: 30px;">
                                                    <span style="font-weight: 500; font-size: 20px;">No Address Added!</span>
                                                    <br>
                                                    <span>Please add one!</span>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            <?php else: ?>
                                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="_1CeZIA " id="AddressContainer<?php echo e($address->id); ?>">
                                    <div class="_26SF1Q">
                                        <div class="umgxnI">
                                            <div class="dpjmKp">
                                                <img src="<?php echo e(asset('img/svg/dots.svg')); ?>">
                                                <div class="_3E8aIl _1UHYca">
                                                    <div class="_16FXBY" onclick="EditAddress(<?php echo e($address->id); ?>)">
                                                        <span>Edit</span>
                                                    </div>
                                                    <div class="_16FXBY" onclick="RemoveAddress(<?php echo e($address->id); ?>)">
                                                        <span>Delete</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                            <div class="_2FCIZU">
                                                <span class="_1GczDM"><?php echo e($address->updated_at); ?></span>
                                            </div>
                                            <p class="_2adSi5">
                                                <span class="_3CfVDh"><?php echo e($address->name); ?></span>
                                                <span class="_1Z7fmh _3CfVDh"><?php echo e($address->mobile); ?></span>
                                            </p>
                                            <span class="_2adSi5 WlNme0"><?php echo e($address->house_no); ?>, <?php echo e($address->locality); ?>, <?php echo e($address->city); ?>, <?php echo e($address->district); ?>, <?php echo e($address->state); ?> - 
                                                <span class="_2dQV-8"><?php echo e($address->pin_code); ?></span>
                                            </span>
                                            <div><button type="submit" class="btn btn-sm btn-dark float-right mt-3" onclick="SelectAddress(<?php echo e($address->id); ?>)">Deliver To This Address</button></div>
                                    </div>
                                </div>              
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>


 
    <div class="col-md-9 d-none display-pages-section" id="PaymentSection">
            <div class="account-details-container">
                <div class="right-account-container ">
                    <div class="account-details-title">
                        <span>Choose Payment Method</span>
                    </div>

                    <div class="wishlist-container">
                        <div class="PaymentBoxes" >                            
                                <div class="PaymentMethodContainer">
                                    <div class="payment-option-container paytm_btn" style="cursor: pointer;">
                                        <span>UPI / Credit Card / Debit Card / Netbanking (PayTM)</span>
                                    </div>
                                    
                                    <div class="payment-option-container payu_btn" style="cursor: pointer;">
                                        <span>UPI / Credit Card / Debit Card / Netbanking (PayU)</span>
                                    </div>

                                    <div class="payment-option-container cod_btn" style="cursor: pointer;">
                                        <span>Cash On Delivery (COD)</span>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>





<div class="col-md-3" >
    <div class="account-details-container row" style="padding: 13px 24px;">
        <span style="font-size: 16px; font-weight: 500;">PRICE DETAILS</span>
    </div>
    <div class="account-details-container row">
        <div class="account-menu-items-container">
            <span>MRP</span>
            <span class="float-right">
                <strong><font class="rupees">&#8377;</font>
                    <span id="MRPSpan">
                        
                    </span>
                </strong>
            </span>
        </div>
        <div class="account-menu-items-container">
            <span>Discount</span>
            <span class="float-right">
                <strong style="font-weight: 500; color: #388e3c;">- <font class="rupees">&#8377;</font>
                    <span id="DiscountSpan">
                        
                    </span>
                </strong>
            </span>
        </div>
        <div class="account-menu-items-container">
            <span>Delivery Charges</span>
            <span class="float-right">
                <strong style="font-weight: 500; color: #388e3c;">FREE</strong>
            </span>
        </div>
        <div class="account-menu-items-container"  style="font-weight: 600; color: black; font-size: 18px; border-top: 1px dashed #e0e0e0; border-bottom: 1px dashed #e0e0e0; margin-top: 18px; margin-bottom: 18px;">
            <span>Total Amount</span>
            <span class="float-right"><font class="rupees">&#8377;</font>
                <span id="TotalSpan">
                    
                </span>
            </span>
        </div>
       
            <div class="w-100 cart-checkout-btn-container">
                <button type="submit" class="OrderSummaryBtn">Next &nbsp;<i class="fa fa-credit-card" aria-hidden="true"></i></button>
                <button type="submit" class="PaymentBtn d-none">Proceed To Pay &nbsp;<i class="fa fa-credit-card" aria-hidden="true"></i></button>
                <button type="submit" class="PayNowBtn d-none" form="CheckoutForm">Pay Now &nbsp;<i class="fa fa-credit-card" aria-hidden="true"></i></button>
            </div>
        
        <div class="account-menu-break"></div> 
    </div>
</div>


    </div>
</div>
<?php $__env->stopSection(); ?>






<?php $__env->startSection('bottom-js'); ?>
<script>
    $(document).ready(function () {
        syncPrice();
    })

    function syncPrice() {
        var product_ids = $('.product_ids').map(function(){ 
                    return this.value; 
            }).get();

        var qtys = $('.qtys').map(function(){ 
                    return this.value; 
            }).get();

        $.ajax({
                url: "<?php echo e(route('sync-price')); ?>",
                method: 'POST',
                data: {
                    'product_ids'   : product_ids,
                    'qtys'          : qtys,
                },
                success: function (data) {
                    $('#MRPSpan').html(data.mrp)
                    $('#TotalSpan').html(data.price)
                    $('#DiscountSpan').html(data.discount)
                }

        })
    }
</script>


<script>
    $('.paytm_btn').click(function () {
        $('.payment-option-container').removeClass('payment-option-active')
        $(this).addClass('payment-option-active')
        $('#CheckoutForm').find("input[name='payment_method']").val('paytm')
    })
    $('.payu_btn').click(function () {
        $('.payment-option-container').removeClass('payment-option-active')
        $(this).addClass('payment-option-active')
        $('#CheckoutForm').find("input[name='payment_method']").val('payu')
    })
    $('.cod_btn').click(function () {
        $('.payment-option-container').removeClass('payment-option-active')
        $(this).addClass('payment-option-active')
        $('#CheckoutForm').find("input[name='payment_method']").val('cod')
    })
</script>

<script>
    $('.PaymentBtn').click(function (e) {
        e.preventDefault()
        console.log('Working');
        $('.display-pages-section').addClass('d-none')
        $('#PaymentSection').removeClass('d-none')
        $('.PaymentBtn').addClass('d-none')
        $('.PayNowBtn').removeClass('d-none')
    })
</script>

<script>
    // Change QTY (Fetching price and MRP using AJAX)
        function ChangeQty(ProdID) {

            syncPrice();

            var qty = $('#product-quantity-'+ProdID).val()

            $.ajax({
                url: "<?php echo e(route('calc-mrp-price')); ?>",
                method: 'POST',
                data: {
                    'ProdID'   : ProdID,
                    'qty'      : qty,
                },
                success: function (data) {
                    $('#MRPField'+ProdID).html(data.mrp)
                    $('#PriceField'+ProdID).html(data.price)
                }
            })
    }
</script>

<script>

    // Select and Highlight Address
    function SelectAddress(AddressID) {
            $('.AddressSelected').removeClass('AddressSelected')
            $('#CheckoutForm').find("input[name='address_id']").val(AddressID)
            $('#AddressContainer'+AddressID).addClass('AddressSelected')
        }

    // If order is selected change page from Address to Summary
    $('.OrderSummaryBtn').click(function (e) {
        e.preventDefault()
      
        if ($('#CheckoutForm').find("input[name='address_id']").val() != '' ) {
            $('.display-pages-section').addClass('d-none')
            $('#OrderSummarySection').removeClass('d-none')
            $('.OrderSummaryBtn').addClass('d-none')
            $('.PaymentBtn').removeClass('d-none')
        } else {
            $(".bootstrap-growl").remove();
            $.bootstrapGrowl("Please Select Address First.", {
                        type: "danger",
                        offset: {from:"bottom", amount: 50},
                        align: 'center',
                        allow_dismis: true,
                        stack_spacing: 10,
                    })
        }
        
    })
</script>






<script>
    function EditAddress(AddressID) {
      
        $.ajax({
            url: "<?php echo e(route('edit-address-fetch')); ?>",
            method: 'POST',
            data: {
                'AddressID'      : AddressID,
            },
            success: function (data) {
                console.log(data)
                $('#EditAddressForm').find("input[name='address_id']").val(data.address.id)
                $('#EditAddressForm').find("input[name='name']").val(data.address.name)
                $('#EditAddressForm').find("input[name='house']").val(data.address.house_no)
                $('#EditAddressForm').find("input[name='locality']").val(data.address.locality)
                $('#EditAddressForm').find("input[name='city']").val(data.address.city)
                $('#EditAddressForm').find("input[name='district']").val(data.address.district)
                $('#EditAddressForm').find("input[name='state']").val(data.address.state)
                $('#EditAddressForm').find("input[name='pin_code']").val(data.address.pin_code)
                $('#EditAddressForm').find("input[name='mobile']").val(data.address.mobile)
                $('#EditAddressForm').find("input[name='altMobile']").val(data.address.alt_mobile)
                $('#EditAddressModal').modal("toggle")
            }
        })
    }

    $('#EditAddressForm').submit(function (e) {
        e.preventDefault()

        $.ajax({
            url: "<?php echo e(route('edit-address-submit')); ?>",
            method: 'POST',
            data: {
                '_token'        : $(this).find("input[name='_token']").val(),
                'address_id'    : $(this).find("input[name='address_id']").val(),
                'name'          : $(this).find("input[name='name']").val(),
                'house'         : $(this).find("input[name='house']").val(),
                'locality'      : $(this).find("input[name='locality']").val(),
                'city'          : $(this).find("input[name='city']").val(),
                'district'      : $(this).find("input[name='district']").val(),
                'state'         : $(this).find("input[name='state']").val(),
                'pin_code'      : $(this).find("input[name='pin_code']").val(),
                'mobile'        : $(this).find("input[name='mobile']").val(),
                'altMobile'     : $(this).find("input[name='altMobile']").val(),
            },
            success: function (data) {
                if (data.status == 200) {
                    $('#EditAddressForm').find("input[name='address_id']").val('')
                    $('#EditAddressForm').find("input[name='name']").val('')
                    $('#EditAddressForm').find("input[name='house']").val('')
                    $('#EditAddressForm').find("input[name='locality']").val('')
                    $('#EditAddressForm').find("input[name='city']").val('')
                    $('#EditAddressForm').find("input[name='district']").val('')
                    $('#EditAddressForm').find("input[name='state']").val('')
                    $('#EditAddressForm').find("input[name='pin_code']").val('')
                    $('#EditAddressForm').find("input[name='mobile']").val('')
                    $('#EditAddressForm').find("input[name='altMobile']").val('')

                    $('#EditAddressModal').modal("toggle")

                    $('#addresses-container-div').load("<?php echo e(route('CheckoutAddressContainerDiv')); ?> #addresses-container-div")
                    $(".bootstrap-growl").remove();
                    $.bootstrapGrowl("Address Updated.", {
                        type: "success",
                        offset: {from:"bottom", amount: 50},
                        align: 'center',
                        allow_dismis: true,
                        stack_spacing: 10,
                    })
                }
            }
        })
    })

    function RemoveAddress(AddressID) {

            $.ajax({
            url: "<?php echo e(route('remove-address-submit')); ?>",
            method: 'POST',
            data: {
                'AddressID'      : AddressID,
            },
            success: function (data) {
                if (data == 200) {
                    $(".bootstrap-growl").remove();
                    $.bootstrapGrowl("Address Removed.", {
                        type: "info",
                        offset: {from:"bottom", amount: 50},
                        align: 'center',
                        allow_dismis: true,
                        stack_spacing: 10,
                    })
                    $('#addresses-container-div').load("<?php echo e(route('CheckoutAddressContainerDiv')); ?> #addresses-container-div")
                    
                    if (AddressID == $('#CheckoutForm').find("input[name='address_id']").val()) {
                        $('#CheckoutForm').find("input[name='address_id']").val('')
                    }
                }
            }
        })
    }

    $('#AddAddressForm').submit(function (e) { 
        
        e.preventDefault()

        var _token    = $(this).find("input[name='_token']").val()
        var name      = $(this).find("input[name='name']").val()
        var house     = $(this).find("input[name='house']").val()
        var locality  = $(this).find("input[name='locality']").val()
        var city      = $(this).find("input[name='city']").val()
        var district  = $(this).find("input[name='district']").val()
        var state     = $(this).find("input[name='state']").val()
        var pin_code  = $(this).find("input[name='pin_code']").val()
        var mobile    = $(this).find("input[name='mobile']").val()
        var altMobile = $(this).find("input[name='altMobile']").val()

            $.ajax({
            url: "<?php echo e(route('add-address-submit')); ?>",
            method: 'POST',
            data: {
                '_token'    : _token,
                'name'      : name,
                'house'     : house,
                'locality'  : locality,
                'city'      : city,
                'district'  : district,
                'state'     : state,
                'pin_code'  : pin_code,
                'mobile'    : mobile,
                'altMobile' : altMobile,
            },
            success: function (data) {
                if (data.status == 200) {
                    $('#AddAddressForm').find("input[name='name']").val('')
                    $('#AddAddressForm').find("input[name='house']").val('')
                    $('#AddAddressForm').find("input[name='locality']" ).val('')
                    $('#AddAddressForm').find("input[name='city']").val('')
                    $('#AddAddressForm').find("input[name='district']").val('')
                    $('#AddAddressForm').find("input[name='state']").val('')
                    $('#AddAddressForm').find("input[name='pin_code']").val('')
                    $('#AddAddressForm').find("input[name='mobile']" ).val('')
                    $('#AddAddressForm').find("input[name='altMobile']").val('')

                    $(".bootstrap-growl").remove();

                    $.bootstrapGrowl("Address Added.", {
                        type: "success",
                        offset: {from:"bottom", amount: 50},
                        align: 'center',
                        allow_dismis: true,
                        stack_spacing: 10,
                    })

                    $('#AddAddressModal').modal('toggle');

                    $('#addresses-container-div').load("<?php echo e(route('CheckoutAddressContainerDiv')); ?> #addresses-container-div")
                }
            }
        })
    })
</script>
<?php $__env->stopSection(); ?>

































<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/checkout-form.blade.php ENDPATH**/ ?>