

<?php $__env->startSection('nav-admin-user-management', 'active'); ?>
<?php $__env->startSection('title','Admin User Management'); ?>

<?php $__env->startSection('css-js'); ?>
<style>
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
        padding: 12px 15px;
        vertical-align: middle;
    }
    table.table tr th:last-child {
        width: 100px;
    }
    table.table-striped tbody tr:nth-of-type(odd) {
        background-color: #fcfcfc;
    }
    table.table-striped.table-hover tbody tr:hover {
        background: #f5f5f5;
    }
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }	
    table.table td:last-child i {
        opacity: 0.9;
        font-size: 22px;
        margin: 0 5px;
    }
    table.table td a {
        font-weight: bold;
        color: #566787;
        display: inline-block;
        text-decoration: none;
    }
    table.table td a:hover {
        color: #2196F3;
    }
    table.table td a.settings {
        color: #2196F3;
    }
    table.table td a.delete {
        color: #F44336;
    }
    table.table td i {
        font-size: 19px;
    }
    table.table .avatar {
        border-radius: 50%;
        vertical-align: middle;
        margin-right: 10px;
    }
    .status {
        font-size: 30px;
        margin: 2px 2px 0 0;
        display: inline-block;
        vertical-align: middle;
        line-height: 10px;
    }
    .text-success {
        color: #10c469;
    }
    .text-info {
        color: #62c9e8;
    }
    .text-warning {
        color: #FFC107;
    }
    .text-danger {
        color: #ff5b5b;
    }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container-fluid">







  <?php $__currentLoopData = $AdminUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AdminUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      

  <div class="modal fade" id="UserDeleteConfirmationModal-<?php echo e($AdminUser->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><strong>Admin Remove Confirmation</strong> </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          Are you sure removing this user from Admin access?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a type="button" class="btn btn-danger" href="<?php echo e(url('/admin/user-management/id/'.$AdminUser->id.'/delete')); ?>">Remove</a>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







  <div class="modal fade" id="CreateNewAdminUserModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><strong>Add New Admin User</strong> </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

            <form method="post" id="UserSearchForm">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input type="email" name="email" class="form-control" placeholder="Registered Email ID">
                  <small class="text-muted">Search the user by typing the user's registered email.</small>
                </div>
                <button type="submit" class="btn btn-primary float-right">Search User</button>
            </form>



            <form id="CreateAdminUserForm" action="<?php echo e(route('admin-user-create-submit')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
                <input type="text" id="user_id_form_input" name="user_id" value="">
            </form>
            
            <button type="submit" class="btn btn-success d-none" id="CreateAdminUserFormSubmitBtn" form="CreateAdminUserForm">Give this user Admin access &nbsp;<i id="CreateAdminFormSpinner" class="fa fa-spinner fa-spin d-none"></i></button>
            
<br><br><br>

            <div id="UserDetailsDiv"></div>
            <div id="CreateUserFormDiv"></div>
          </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>





















<h3>Admin User Management</h3>










<?php if(Session::has('AdminUserAdded')): ?>
    <div class="alert alert-success" id="admin_user_created_alert" role="alert">
        Admin user created successfully. <strong><?php echo e(session('AdminUserAdded')); ?></strong>
    </div>
<?php endif; ?>

<?php if(Session::has('EditSuccess')): ?>
    <div class="alert alert-success" id="admin_user_created_alert" role="alert">
        User edited succesfully. <strong><?php echo e(session('EditSuccess')); ?></strong>
    </div>
<?php endif; ?>

<?php if(Session::has('MasterAdminRemove')): ?>
<div class="alert alert-danger" role="alert">
    You cannot edit any user with <strong>Master Admin</strong> role. 
</div>
<?php endif; ?>

<?php if(Session::has('SelfEdit')): ?>
<div class="alert alert-danger" role="alert">
    You cannot edit yourself. <strong><?php echo e(session('SelfEdit')); ?></strong>
</div>
<?php endif; ?>

<?php if(Session::has('self_remove')): ?>
<div class="alert alert-danger" role="alert">
    You cannot remove yourself. <strong><?php echo e(session('self_remove')); ?></strong>
</div>
<?php endif; ?>

<?php if(Session::has('master_admin_remove')): ?>
<div class="alert alert-danger" role="alert">
    You cannot remove any user with Master Admin role. <strong><?php echo e(session('master_admin_remove')); ?></strong>
</div>
<?php endif; ?>

<?php if(Session::has('admin_removed')): ?>
<div class="alert alert-success" role="alert">
    Admin removed successfully with email <strong><?php echo e(session('admin_removed')); ?></strong>
</div>
<?php endif; ?>





<div class="row"><div class="col">
<button class="btn btn-primary float-right d-block mb-3" data-toggle="modal" data-target="#CreateNewAdminUserModal">Create New Admin User</button>
</div></div>



<!--user Table Start-->
<table id="userTable" class="table table-striped table-bordered table-fluid d-none">
    <thead class="bg-primary text-white">
    <tr>
        <th>Name</th>
        <th>Email ID</th>
        <th>Date Created</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $AdminUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AdminUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="#"><img width="25px" height="25px" class="avatar" style="border-radius: 50%" src="<?php echo e('/storage/images/dp/'.$AdminUser->dp); ?>"> <?php echo e($AdminUser->name); ?></a></td>
            <td><a href="#"><?php echo e($AdminUser->email); ?></a></td>
            <td><?php echo e($AdminUser->created_at); ?></td>
            <?php if($AdminUser->status == 'active'): ?><td><span class="status text-success">&bull;</span>Active</td><?php elseif($AdminUser->status == 'suspended'): ?><td><span class="status text-success">&bull;</span>Suspended</td><?php else: ?><td><span class="status">&bull;</span>Error</td><?php endif; ?>
            <td>
                <a href="<?php echo e(url('admin/user-management/id/'.$AdminUser->id.'/edit')); ?>" class="setting" title="Edit" ><i class="fa fa-cog"></i> </a>
                <a href="" class="delete" data-toggle="modal" data-target="#UserDeleteConfirmationModal-<?php echo e($AdminUser->id); ?>" title="Remove User"><i class="fa fa-times"></i></a>
            </td>  
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
    <tr>
        <th>Name</th>
        <th>Email ID</th>
        <th>Date Created</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    </tfoot>
</table>

<!--user Table End-->






</div> <!--Container-Fluid End-->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>
<script>
    $(document).ready(function() {
        $('#userTable').removeClass('d-none')
        $('#userTable').DataTable();
    } );
</script>

<script>
    $('#UserSearchForm').submit(function (e) {
        
        e.preventDefault()
        var _token  = $('input[name="_token"]').val()
        var email   = $('input[name="email"]').val()

        $.ajax({
            url: "<?php echo e(route('admin-user-search-submit')); ?>",
            method: "POST",
            data: {
                _token  :_token,
                email   :email,
            },
            success: function(data) {
                if (data.status == 200) {
                    console.log(data)

            var user_details_table = `
            <table style="width: 100%;">
                <tr>
                    <td>Name:</td>
                    <td><strong>${data.name}</strong></td>
                </tr>
                <tr>
                    <td>Email ID:</td>
                    <td><strong>${data.email}</strong></td>
                </tr>
                <tr>
                    <td>Mobile Number:</td>
                    <td><strong>${data.mobile}</strong></td>
                </tr>
                <tr>
                    <td>Created At:</td>  
                    <td><strong>${data.created_at}</strong></td>                      
                </tr>
                <tr>
                    <td>Updated At:</td>
                    <td><strong>${data.updated_at}</strong></td>
                </tr>
            </table> `

            
            $('#user_id_form_input').val(data.user_id)

            $('#CreateUserFormDiv').fadeIn()
            $('#CreateUserFormDiv').html(user_details_table)
            $('#CreateAdminUserFormSubmitBtn').removeClass('d-none')

                    
                }else {
                    $('#CreateUserFormDiv').fadeIn()
                    $('#CreateUserFormDiv').html(data)
                }
            },
        })
    })
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/user-management.blade.php ENDPATH**/ ?>