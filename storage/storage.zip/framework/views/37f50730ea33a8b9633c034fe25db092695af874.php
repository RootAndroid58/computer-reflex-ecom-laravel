<?php $__env->startSection('nav-dashboard', 'active'); ?>
<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>

<div class="container-fluid"> <!--Container-Fluid Start-->

    <h3 class="text-dark">Dashboard</h3>

            <div class="row">

                <div class="col-md-6 col-xl-3 mb-4">
                    <div class="card shadow border-left-primary py-2">
                        <div class="card-body">
                            <div class="row align-items-center no-gutters">
                                <div class="col mr-2">
                                    <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>Date</span></div>
                                    <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo e(date('dS M, Y (D)')); ?></span></div>
                                </div>
                                <div class="col-auto"><i class="fas fa-calendar fa-2x text-gray-300"></i></div>
                            </div>
                        </div> 
                    </div>
                </div>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Manage Orders', 'Admin'])): ?>
                <div class="col-md-6 col-xl-3 mb-4">
                    <div class="card shadow border-left-success py-2">
                        <div class="card-body">
                            <div class="row align-items-center no-gutters">
                                <div class="col mr-2">
                                    <div class="text-uppercase text-success font-weight-bold text-xs mb-1"><span>Orders in Last 28 Days</span></div>
                                    <div class="text-dark font-weight-bold h5 mb-0"><span>
                                        <?php echo e(App\Models\Order::whereNotIn('status', ['checkout_pending', 'payment_failed', 'payment_pending'])->count()); ?> Orders
                                    </span></div>
                                </div>
                                <div class="col-auto"><i class="fa fa-inr fa-2x text-gray-300"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['User Management', 'Admin'])): ?>
                <div class="col-md-6 col-xl-3 mb-4">
                    <div class="card shadow border-left-dark py-2">
                        <div class="card-body">
                            <div class="row align-items-center no-gutters">
                                <div class="col mr-2">
                                    <div class="text-uppercase text-success font-weight-bold text-xs mb-1"><span>Total Users</span></div>
                                    <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo e(App\Models\User::count()); ?> Users</span></div>
                                </div>
                                <div class="col-auto"><i class="fas fa-users fa-2x text-gray-300"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Manage Orders', 'Admin'])): ?>
                <div class="col-md-6 col-xl-3 mb-4">
                    <div class="card shadow border-left-warning py-2">
                        <div class="card-body">
                            <div class="row align-items-center no-gutters">
                                <div class="col mr-2">
                                    <div class="text-uppercase text-warning font-weight-bold text-xs mb-1"><span>Orders Not Shipped Yet</span></div>
                                    <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo e(App\Models\Order::where('status', 'order_placed')->orwhere('status', 'order_packing')->orwhere('status', 'packing_completed')->orwhere('status', 'shipment_created')->count()); ?> Orders</span></div>
                                </div>
                                <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
                

                <div class="row"> <!--Buttons Row Start-->

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Manage Orders', 'Admin'])): ?>
                    <div class="col-lg-6 mb-4">
                        <div class="card text-white bg-primary shadow">
                            <a href="<?php echo e(route('admin-manage-orders')); ?>" class="btn btn-primary btn-lg pt-3 pb-3"><b>MANAGE ORDERS</b></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Manage Products', 'Admin'])): ?>
                    <div class="col-lg-6 mb-4">
                        <div class="card text-white bg-primary shadow">
                            <a href="<?php echo e(route('admin-manage-products')); ?>" class="btn btn-primary btn-lg pt-3 pb-3"><b>MANAGE PRODUCTS</b></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Manage Orders', 'Admin'])): ?>
                    <div class="col-lg-6 mb-4">
                        <div class="card text-white bg-primary shadow">
                            <a href="<?php echo e(route('admin-user-management')); ?>" class="btn btn-primary btn-lg pt-3 pb-3"><b>USER MANAGEMENT</b></a>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Support Staff', 'Admin'])): ?>
                    <div class="col-lg-6 mb-4">
                        <div class="card text-white bg-primary shadow">
                            <a href="<?php echo e(route('admin-support-tickets')); ?>" class="btn btn-primary btn-lg pt-3 pb-3"><b>TICKETS</b></a>
                        </div>
                    </div>
                    <?php endif; ?>


                </div> <!--Buttons Row End-->






</div> <!--Container-Fluid End--->


        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>