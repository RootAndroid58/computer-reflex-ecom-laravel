

<?php $__env->startSection('nav-manage-ui', 'active'); ?>
<?php $__env->startSection('title','Manage UI'); ?>

<?php $__env->startSection('css-js'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid">

    <div id="container">

<h3>UI Management</h3>

<div class="row">
    <div class="col-md-3">
        <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('admin-manage-banners')); ?>">Manage Banners</a>
    </div>
    <div class="col-md-3">
        <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('admin-manage-home-carousel-sliders')); ?>">Home Products Carousels</a>
    </div>
    <div class="col-md-3">
        <a class="btn btn-lg btn-block btn-primary" href="<?php echo e(route('admin-manage-featured-catalogs')); ?>">Featured Catalogs</a>
    </div>
</div>




</div></div> <!--Container-Fluid End-->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bottom-js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\ComputerReflex\resources\views/admin/manage-ui.blade.php ENDPATH**/ ?>